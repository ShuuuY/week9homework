--****PLEASE ENTER YOUR DETAILS BELOW****
--T3-rm-dm.sql

--Student ID:31519601
--Student Name:Shuyan Gong
--Unit Code:FIT2094
--Applied Class No:06

/* Comments for your marker:
For (b), I inserted competitor with his/her entry one by one, 
so when i inserted entries for competitors, i used max(comp_no for 
search the value.



*/

/*3(a)*/
DROP SEQUENCE seq_t;

DROP SEQUENCE seq_c;

CREATE SEQUENCE seq_t
start with 100
increment by 1
maxvalue 999
cycle;

CREATE SEQUENCE seq_c
start with 100
increment by 1
maxvalue 99999
cycle;

--3(b)
INSERT INTO emercontact (
    ec_phone,
    ec_fname,
    ec_lname
) VALUES (
    '0476541234',
    'Jack',
    'Kai'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    seq_c.nextval,
    'Daniel',
    'Kai',
    'M',
    TO_DATE('10/JUN/2000', 'DD/MON/YYYY'),
    'Daniel@student.monash.edu',
    'Y',
    '8850815877',
    'P',
    '0476541234'
);
--select * from competitor;
INSERT INTO entry (
    event_id,
    entry_no,
    comp_no,
    char_id
) VALUES (
    (
        SELECT
            event_id
        FROM
                 carnival
            JOIN event
            ON carnival.carn_date = event.carn_date
            JOIN eventtype
            ON event.eventtype_code = eventtype.eventtype_code
        WHERE
                carn_name = 'RM Autumn Series Caulfield 2022'
            AND eventtype_desc = '21.1 Km Half Marathon'
    ),
    (
        SELECT
            MAX(entry_no) + 1
        FROM
            entry
        WHERE
            event_id = (
                SELECT
                    event_id
                FROM
                         carnival
                    JOIN event
                    ON carnival.carn_date = event.carn_date
                    JOIN eventtype
                    ON event.eventtype_code = eventtype.eventtype_code
                WHERE
                        carn_name = 'RM Autumn Series Caulfield 2022'
                    AND eventtype_desc = '21.1 Km Half Marathon'
            )
    ),
    (
        SELECT
            MAX(comp_no)
        FROM
            competitor
    ),
    (
        SELECT
            char_id
        FROM
            charity
        WHERE
            char_name = 'Beyond Blue'
    )
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    seq_c.nextval,
    'Annabelle',
    'Kai',
    'F',
    TO_DATE('08/Feb/2002', 'DD/MON/YYYY'),
    'Annabelle@student.monash.edu',
    'Y',
    '2258288992',
    'P',
    '0476541234'
);

INSERT INTO entry (
    event_id,
    entry_no,
    comp_no,
    char_id
) VALUES (
    (
        SELECT
            event_id
        FROM
                 carnival
            JOIN event
            ON carnival.carn_date = event.carn_date
            JOIN eventtype
            ON event.eventtype_code = eventtype.eventtype_code
        WHERE
                carn_name = 'RM Autumn Series Caulfield 2022'
            AND eventtype_desc = '21.1 Km Half Marathon'
    ),
    (
        SELECT
            MAX(entry_no) + 1
        FROM
            entry
        WHERE
            event_id = (
                SELECT
                    event_id
                FROM
                         carnival
                    JOIN event
                    ON carnival.carn_date = event.carn_date
                    JOIN eventtype
                    ON event.eventtype_code = eventtype.eventtype_code
                WHERE
                        carn_name = 'RM Autumn Series Caulfield 2022'
                    AND eventtype_desc = '21.1 Km Half Marathon'
            )
    ),
    (
        SELECT
            MAX(comp_no)
        FROM
            competitor
    ),
    (
        SELECT
            char_id
        FROM
            charity
        WHERE
            char_name = 'Amnesty International'
    )
);
commit;
--select * from entry;
--3(c)
INSERT INTO team (
    team_id,
    team_name,
    carn_date,
    team_no_members,
    event_id,
    entry_no,
    char_id
) VALUES (
    seq_t.NEXTVAL,
    'Kai Speedstars',
    (
        SELECT
            carn_date
        FROM
            carnival
        WHERE
            carn_name = 'RM Autumn Series Caulfield 2022'
    ),
    1,
    (
        SELECT
            event_id
        FROM
                 carnival
            JOIN event
            ON carnival.carn_date = event.carn_date
            JOIN eventtype
            ON event.eventtype_code = eventtype.eventtype_code
        WHERE
                carn_name = 'RM Autumn Series Caulfield 2022'
            AND eventtype_desc = '21.1 Km Half Marathon'
    ),
    (
        SELECT
            entry_no
        FROM
                 entry
            JOIN competitor
            ON entry.comp_no = competitor.comp_no
        WHERE
                event_id = (
                    SELECT
                        event_id
                    FROM
                             carnival
                        JOIN event
                        ON carnival.carn_date = event.carn_date
                        JOIN eventtype
                        ON event.eventtype_code = eventtype.eventtype_code
                    WHERE
                            carn_name = 'RM Autumn Series Caulfield 2022'
                        AND eventtype_desc = '21.1 Km Half Marathon'
                )
            AND comp_fname = 'Annabelle'
            AND comp_lname = 'Kai'
    ),
    (
        SELECT
            char_id
        FROM
            charity
        WHERE
            char_name = 'Beyond Blue'
    )
);
UPDATE entry
SET
    team_id = (
        SELECT
            team_id
        FROM
            team
        WHERE
                team_name = 'Kai Speedstars'
            AND carn_date = (
                SELECT
                    carn_date
                FROM
                    carnival
                WHERE
                    carn_name = 'RM Autumn Series Caulfield 2022'
            )
    )
WHERE
        event_id = (
            SELECT
                event_id
            FROM
                     carnival
                JOIN event
                ON carnival.carn_date = event.carn_date
                JOIN eventtype
                ON event.eventtype_code = eventtype.eventtype_code
            WHERE
                    carn_name = 'RM Autumn Series Caulfield 2022'
                AND eventtype_desc = '21.1 Km Half Marathon'
        )
    AND comp_no = (
        SELECT
            entry.comp_no
        FROM
                 competitor
            JOIN entry
            ON competitor.comp_no = entry.comp_no
        WHERE
                comp_fname = 'Annabelle'
            AND comp_lname = 'Kai'
                AND event_id = (
                SELECT
                    event_id
                FROM
                         carnival
                    JOIN event
                    ON carnival.carn_date = event.carn_date
                    JOIN eventtype
                    ON event.eventtype_code = eventtype.eventtype_code
                WHERE
                        carn_name = 'RM Autumn Series Caulfield 2022'
                    AND eventtype_desc = '21.1 Km Half Marathon'
            )
    );
--
--SELECT
--    *
--FROM
--    entry;
--
--COMMIT;

/*3(d)*/
UPDATE entry
SET
    event_id = (
        SELECT
            event_id
        FROM
                 carnival
            JOIN event
            ON carnival.carn_date = event.carn_date
            JOIN eventtype
            ON event.eventtype_code = eventtype.eventtype_code
        WHERE
                carn_name = 'RM Autumn Series Caulfield 2022'
            AND eventtype_desc = '10 Km Run'
    ),
    entry_no = (
        SELECT
            MAX(entry_no) + 1
        FROM
            entry
        WHERE
            event_id = (
                SELECT
                    event_id
                FROM
                         carnival
                    JOIN event
                    ON carnival.carn_date = event.carn_date
                    JOIN eventtype
                    ON event.eventtype_code = eventtype.eventtype_code
                WHERE
                        carn_name = 'RM Autumn Series Caulfield 2022'
                    AND eventtype_desc = '10 Km Run'
            )
    ),
    team_id = (
        SELECT
            team_id
        FROM
            team
        WHERE
                team_name = 'Kai Speedstars'
            AND carn_date = (
                SELECT
                    carn_date
                FROM
                    carnival
                WHERE
                    carn_name = 'RM Autumn Series Caulfield 2022'
            )
    )
WHERE
        event_id = (
            SELECT
                event_id
            FROM
                     carnival
                JOIN event
                ON carnival.carn_date = event.carn_date
                JOIN eventtype
                ON event.eventtype_code = eventtype.eventtype_code
            WHERE
                    carn_name = 'RM Autumn Series Caulfield 2022'
                AND eventtype_desc = '21.1 Km Half Marathon'
        )
    AND entry_no = (
        SELECT
            entry_no
        FROM
                 entry
            JOIN competitor
            ON entry.comp_no = competitor.comp_no
        WHERE
                event_id = (
                    SELECT
                        event_id
                    FROM
                             carnival
                        JOIN event
                        ON carnival.carn_date = event.carn_date
                        JOIN eventtype
                        ON event.eventtype_code = eventtype.eventtype_code
                    WHERE
                            carn_name = 'RM Autumn Series Caulfield 2022'
                        AND eventtype_desc = '21.1 Km Half Marathon'
                )
            AND comp_fname = 'Daniel'
                AND comp_lname = 'Kai'
    );
/*    comp_no = (*/
/*        select*/
/*            entry.comp_no*/
/*        from*/
/*            competitor join entry*/
/*            on competitor.comp_no = entry.comp_no*/
/*        where*/
/*            comp_fname = 'Daniel' and comp_lname = 'Kai' and*/
/*            event_id = (SELECT*/
/*            event_id*/
/*        FROM*/
/*                 carnival*/
/*            JOIN event*/
/*            ON carnival.carn_date = event.carn_date*/
/*            JOIN eventtype*/
/*            ON event.eventtype_code = eventtype.eventtype_code*/
/*        WHERE*/
/*                carn_name = 'RM Autumn Series Caulfield 2022'*/
/*            AND eventtype_desc = '21.1 Km Half Marathon'));*/

UPDATE team
SET
    team_no_members = team_no_members + 1
WHERE
        team_name = 'Kai Speedstars'
    AND carn_date = (
        SELECT
            carn_date
        FROM
            carnival
        WHERE
            carn_name = 'RM Autumn Series Caulfield 2022'
    );

COMMIT;

/*3(e)*/
DELETE FROM entry
WHERE
        event_id = (
            SELECT
                event_id
            FROM
                     carnival
                JOIN event
                ON carnival.carn_date = event.carn_date
                JOIN eventtype
                ON event.eventtype_code = eventtype.eventtype_code
            WHERE
                    carn_name = 'RM Autumn Series Caulfield 2022'
                AND eventtype_desc = '10 Km Run'
        )
    AND comp_no = (
        SELECT
            entry.comp_no
        FROM
                 competitor
            JOIN entry
            ON competitor.comp_no = entry.comp_no
        WHERE
                comp_fname = 'Daniel'
            AND comp_lname = 'Kai'
                AND event_id = (
                SELECT
                    event_id
                FROM
                         carnival
                    JOIN event
                    ON carnival.carn_date = event.carn_date
                    JOIN eventtype
                    ON event.eventtype_code = eventtype.eventtype_code
                WHERE
                        carn_name = 'RM Autumn Series Caulfield 2022'
                    AND eventtype_desc = '10 Km Run'
            )
    );

UPDATE entry
SET
    team_id = NULL,
    char_id = (
        SELECT
            char_id
        FROM
            charity
        WHERE
            char_name = 'Beyond Blue'
    )
WHERE
    comp_no = (
        SELECT
            entry.comp_no
        FROM
                 competitor
            JOIN entry
            ON competitor.comp_no = entry.comp_no
        WHERE
                comp_fname = 'Annabelle'
            AND comp_lname = 'Kai'
                AND team_id = (
                SELECT
                    team_id
                FROM
                    team
                WHERE
                    team_name = 'Kai Speedstars'
            )
    );
/*UPDATE entry*/
/*SET*/
/*    char_id = (*/
/*        SELECT*/
/*            char_id*/
/*        FROM*/
/*            charity*/
/*        WHERE*/
/*            char_name = 'Beyond Blue'*/
/*    )*/
/*WHERE*/
/*    comp_no = (*/
/*        SELECT*/
/*            entry.comp_no*/
/*        FROM*/
/*                 competitor*/
/*            JOIN entry*/
/*            ON competitor.comp_no = entry.comp_no*/
/*        WHERE*/
/*                comp_fname = 'Annabelle'*/
/*            AND comp_lname = 'Kai'*/
/*            AND event_id = (*/
/*                SELECT*/
/*                    event_id*/
/*                FROM*/
/*                         carnival*/
/*                    JOIN event*/
/*                    ON carnival.carn_date = event.carn_date*/
/*                    JOIN eventtype*/
/*                    ON event.eventtype_code = eventtype.eventtype_code*/
/*                WHERE*/
/*                        carn_name = 'RM Autumn Series Caulfield 2022'*/
/*                    AND eventtype_desc = '21.1 Km Half Marathon'*/
/*            )*/
/*    );*/

DELETE FROM team
WHERE
        team_name = 'Kai Speedstars'
    AND carn_date = (
        SELECT
            carn_date
        FROM
            carnival
        WHERE
            carn_name = 'RM Autumn Series Caulfield 2022'
    );

COMMIT;                                  

