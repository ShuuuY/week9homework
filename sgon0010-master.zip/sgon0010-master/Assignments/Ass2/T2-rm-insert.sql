/*****PLEASE ENTER YOUR DETAILS BELOW*****/
/*T2-rm-insert.sql*/

/*Student ID:31519601*/
/*Student Name:Shuyan Gong*/
/*Unit Code:FIT2094*/
/*Applied Class No:06*/

/* Comments for your marker:




*/

/* Task 2 Load the EMERCONTACT, COMPETITOR, ENTRY and TEAM tables with your own*/
/* test data following the data requirements expressed in the brief*/

/* =======================================*/
/* EMERCONTACT*/
/* =======================================*/
INSERT INTO emercontact (
    ec_phone,
    ec_fname,
    ec_lname
) VALUES (
    '1103278727',
    'Kye',
    'Kaiser'
);

INSERT INTO emercontact (
    ec_phone,
    ec_fname,
    ec_lname
) VALUES (
    '9391758774',
    'Olivia',
    'Huynh'
);

INSERT INTO emercontact (
    ec_phone,
    ec_fname,
    ec_lname
) VALUES (
    '4224285008',
    'Monika',
    'Cottrell'
);

INSERT INTO emercontact (
    ec_phone,
    ec_fname,
    ec_lname
) VALUES (
    '6090767609',
    'Sanaa ',
    'Cornish'
);

INSERT INTO emercontact (
    ec_phone,
    ec_fname,
    ec_lname
) VALUES (
    '8317811491',
    'Ashlyn',
    'Ali'
);

/*SELECT*/
/*    **/
/*FROM*/
/*    entry;*/
/* =======================================*/
/* COMPETITOR*/
/* =======================================*/
INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    1,
    'Daniel',
    'Ali',
    'M',
    TO_DATE('29/May/2006', 'DD/MON/YYYY'),
    'Daniel@student.monash.edu',
    'Y',
    '3576151085',
    'G',
    '8317811491'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    2,
    'Ellisha',
    'Ali',
    'F',
    TO_DATE('20/Aug/2004', 'DD/MON/YYYY'),
    'Ellisha@student.monash.edu',
    'Y',
    '6921397975',
    'G',
    '8317811491'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    3,
    'Ellisha',
    'Woodcock',
    'F',
    TO_DATE('20/Aug/2004', 'DD/MON/YYYY'),
    'Ellisha1@student.monash.edu',
    'Y',
    '8579924580',
    'F',
    '1103278727'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    4,
    'Brenna',
    'Dodson',
    'F',
    TO_DATE('12/Oct/2000', 'DD/MON/YYYY'),
    'Brenna@gmail.com',
    'N',
    '1123781834',
    'P',
    '1103278727'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    5,
    'Alyx',
    'Laing',
    'M',
    TO_DATE('02/Dec/1986', 'DD/MON/YYYY'),
    'Alyx@staff.monash.edu',
    'Y',
    '4251585215',
    'F',
    '8317811491'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    6,
    'Kai',
    'Laing',
    'M',
    TO_DATE('11/Nov/2004', 'DD/MON/YYYY'),
    'Kai@gmail.com',
    'N',
    '3424589809',
    'G',
    '9391758774'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    7,
    'Taiba',
    'Hills',
    'M',
    TO_DATE('15/Jan/1990', 'DD/MON/YYYY'),
    'Taiba@staff.monash.edu',
    'Y',
    '6442315943',
    'P',
    '4224285008'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    8,
    'Sonya',
    'Hills',
    'M',
    TO_DATE('25/Feb/1977', 'DD/MON/YYYY'),
    'Sonya@staff.monash.edu',
    'Y',
    '4931419328',
    'F',
    '8317811491'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    9,
    'Bronwen',
    'Jenkins',
    'F',
    TO_DATE('14/Jul/2001', 'DD/MON/YYYY'),
    'Bronwen@student.monash.edu',
    'Y',
    '4762260198',
    'F',
    '6090767609'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    10,
    'Charlie',
    'Rowe',
    'F',
    TO_DATE('29/Apr/2001', 'DD/MON/YYYY'),
    'Charlie@student.monash.edu',
    'Y',
    '8545573209',
    'F',
    '6090767609'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    11,
    'Dillan',
    'Mcnally',
    'M',
    TO_DATE('07/May/1995', 'DD/MON/YYYY'),
    'Dillan@staff.monash.edu',
    'Y',
    '6871245220',
    'F',
    '1103278727'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    12,
    'Cody',
    'Shah',
    'F',
    TO_DATE('10/Jun/2002', 'DD/MON/YYYY'),
    'Cody@student.monash.edu',
    'Y',
    '8850815177',
    'T',
    '1103278727'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    13,
    'Jean',
    'Jimenez',
    'M',
    TO_DATE('01/Feb/1993', 'DD/MON/YYYY'),
    'Jean@staff.monash.edu',
    'Y',
    '2258238992',
    'T',
    '6090767609'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    14,
    'Marley',
    'Sykes',
    'F',
    TO_DATE('13/Dec/2000', 'DD/MON/YYYY'),
    'Marley@student.monash.edu',
    'Y',
    '1132813575',
    'T',
    '1103278727'
);

INSERT INTO competitor (
    comp_no,
    comp_fname,
    comp_lname,
    comp_gender,
    comp_dob,
    comp_email,
    comp_unistatus,
    comp_phone,
    comp_ec_relationship,
    ec_phone
) VALUES (
    15,
    'Tamar',
    'Devlin',
    'M',
    TO_DATE('24/May/2001', 'DD/MON/YYYY'),
    'Tamar@student.monash.edu',
    'Y',
    '1648351034',
    'T',
    '1103278727'
);

/* =======================================*/
/* ENTRY*/
/* =======================================*/

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    1,
    1,
    TO_DATE('09:30:00', 'HH:MI:SS'),
    TO_DATE('09:54:05', 'HH:MI:SS'),
    1,
    1
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    3,
    1,
    TO_DATE('09:05:11', 'HH:MI:SS'),
    TO_DATE('09:28:54', 'HH:MI:SS'),
    1,
    2
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    7,
    1,
    TO_DATE('08:44:10', 'HH:MI/SS'),
    TO_DATE('09:08:03', 'HH:MI/SS'),
    1,
    3
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    2,
    1,
    TO_DATE('08:40:00', 'HH:MI:SS'),
    TO_DATE('09:49:40', 'HH:MI:SS'),
    2,
    1
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    4,
    1,
    TO_DATE('08:40:00', 'HH:MI:SS'),
    TO_DATE('09:49:35', 'HH:MI:SS'),
    2,
    2
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    8,
    1,
    TO_DATE('08:05:10', 'HH:MI:SS'),
    TO_DATE('09:12:54', 'HH:MI:SS'),
    2,
    2
);

INSERT INTO entry (
    event_id,
    entry_no,
    comp_no
) VALUES (
    14,
    1,
    3
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    1,
    2,
    TO_DATE('09:30:00', 'HH:MI:SS'),
    TO_DATE('09:59:10', 'HH:MI:SS'),
    4,
    1
);

INSERT INTO entry (
    event_id,
    entry_no,
    comp_no
) VALUES (
    13,
    1,
    5
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    5,
    1,
    TO_DATE('08:10:47', 'HH:MI:SS'),
    TO_DATE('11:15:05', 'HH:MI:SS'),
    6,
    2
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    6,
    1,
    TO_DATE('08:35:11', 'HH:MI:SS'),
    TO_DATE('09:54:14', 'HH:MI:SS'),
    7,
    2
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    6,
    2,
    TO_DATE('08:35:11', 'HH:MI/SS'),
    TO_DATE('09:55:03', 'HH:MI/SS'),
    8,
    3
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    6,
    3,
    TO_DATE('08:35:11', 'HH:MI:SS'),
    TO_DATE('09:53:40', 'HH:MI:SS'),
    9,
    3
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    9,
    1,
    TO_DATE('08:04:51', 'HH:MI:SS'),
    TO_DATE('11:10:10', 'HH:MI:SS'),
    10,
    3
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    1,
    3,
    TO_DATE('09:30:00', 'HH:MI:SS'),
    TO_DATE('09:55:35', 'HH:MI:SS'),
    10,
    1
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    3,
    2,
    TO_DATE('09:05:11', 'HH:MI:SS'),
    TO_DATE('09:29:54', 'HH:MI:SS'),
    10,
    2
);

INSERT INTO entry (
    event_id,
    entry_no,
    comp_no
) VALUES (
    13,
    2,
    11
);

INSERT INTO entry (
    event_id,
    entry_no,
    comp_no
) VALUES (
    11,
    1,
    11
);

INSERT INTO entry (
    event_id,
    entry_no,
    comp_no
) VALUES (
    13,
    3,
    12
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no
) VALUES (
    9,
    2,
    TO_DATE('08:04:51', 'HH:MI:SS'),
    TO_DATE('11:34:10', 'HH:MI:SS'),
    11
);

INSERT INTO entry (
    event_id,
    entry_no,
    comp_no
) VALUES (
    11,
    2,
    12
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no
) VALUES (
    9,
    3,
    TO_DATE('08:04:51', 'HH:MI:SS'),
    TO_DATE('11:21:40', 'HH:MI:SS'),
    12
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    9,
    4,
    TO_DATE('08:04:51', 'HH:MI:SS'),
    TO_DATE('11:02:11', 'HH:MI:SS'),
    13,
    3
);

INSERT INTO entry (
    event_id,
    entry_no,
    comp_no
) VALUES (
    13,
    4,
    13
);

INSERT INTO entry (
    event_id,
    entry_no,
    comp_no,
    char_id
) VALUES (
    11,
    3,
    13,
    4
);

INSERT INTO entry (
    event_id,
    entry_no,
    entry_starttime,
    entry_finishtime,
    comp_no,
    char_id
) VALUES (
    9,
    5,
    TO_DATE('08:04:51', 'HH:MI:SS'),
    TO_DATE('11:18:36', 'HH:MI:SS'),
    14,
    3
);

INSERT INTO entry (
    event_id,
    entry_no,
    comp_no
) VALUES (
    13,
    5,
    14
);

INSERT INTO entry (
    event_id,
    entry_no,
    comp_no,
    char_id
) VALUES (
    11,
    4,
    14,
    4
);

INSERT INTO entry (
    event_id,
    entry_no,
    comp_no
) VALUES (
    11,
    5,
    15
);

INSERT INTO entry (
    event_id,
    entry_no,
    comp_no
) VALUES (
    13,
    6,
    15
);

/* =======================================*/
/* TEAM*/
/* =======================================*/
INSERT INTO team (
    team_id,
    team_name,
    carn_date,
    team_no_members,
    event_id,
    entry_no,
    char_id
) VALUES (
    1,
    'The one',
    TO_DATE('24/SEP/2021', 'DD/MON/YYYY'),
    4,
    1,
    1,
    1
);

INSERT INTO team (
    team_id,
    team_name,
    carn_date,
    team_no_members,
    event_id,
    entry_no,
    char_id
) VALUES (
    2,
    'The one',
    TO_DATE('01/OCT/2021', 'DD/MON/YYYY'),
    4,
    4,
    1,
    2
);

INSERT INTO team (
    team_id,
    team_name,
    carn_date,
    team_no_members,
    event_id,
    entry_no,
    char_id
) VALUES (
    3,
    'The Avengers',
    TO_DATE('05/FEB/2022', 'DD/MON/YYYY'),
    8,
    6,
    1,
    3
);

INSERT INTO team (
    team_id,
    team_name,
    carn_date,
    team_no_members,
    event_id,
    entry_no,
    char_id
) VALUES (
    4,
    'MVPS',
    TO_DATE('14/MAR/2022', 'DD/MON/YYYY'),
    2,
    11,
    3,
    4
);

INSERT INTO team (
    team_id,
    team_name,
    carn_date,
    team_no_members,
    event_id,
    entry_no
) VALUES (
    5,
    'Hustlers',
    TO_DATE('29/MAY/2022', 'DD/MON/YYYY'),
    4,
    13,
    1
);

UPDATE entry
SET
    team_id = 1
WHERE
        event_id = 1
    AND entry_no = 1;

UPDATE entry
SET
    team_id = 1
WHERE
        event_id = 2
    AND entry_no = 1;

UPDATE entry
SET
    team_id = 1
WHERE
        event_id = 1
    AND entry_no = 2;

UPDATE entry
SET
    team_id = 1
WHERE
        event_id = 1
    AND entry_no = 3;

UPDATE entry
SET
    team_id = 2
WHERE
        event_id = 3
    AND entry_no = 1;

UPDATE entry
SET
    team_id = 2
WHERE
        event_id = 4
    AND entry_no = 1;

UPDATE entry
SET
    team_id = 2
WHERE
        event_id = 5
    AND entry_no = 1;

UPDATE entry
SET
    team_id = 2
WHERE
        event_id = 3
    AND entry_no = 2;

UPDATE entry
SET
    team_id = 3
WHERE
        event_id = 7
    AND entry_no = 1;

UPDATE entry
SET
    team_id = 3
WHERE
        event_id = 8
    AND entry_no = 1;

UPDATE entry
SET
    team_id = 3
WHERE
        event_id = 6
    AND entry_no = 1;

UPDATE entry
SET
    team_id = 3
WHERE
        event_id = 6
    AND entry_no = 2;

UPDATE entry
SET
    team_id = 3
WHERE
        event_id = 6
    AND entry_no = 3;

UPDATE entry
SET
    team_id = 3
WHERE
        event_id = 9
    AND entry_no = 1;

UPDATE entry
SET
    team_id = 3
WHERE
        event_id = 9
    AND entry_no = 4;

UPDATE entry
SET
    team_id = 3
WHERE
        event_id = 9
    AND entry_no = 5;

UPDATE entry
SET
    team_id = 4
WHERE
        event_id = 11
    AND entry_no = 3;

UPDATE entry
SET
    team_id = 4
WHERE
        event_id = 11
    AND entry_no = 4;

UPDATE entry
SET
    team_id = 5
WHERE
        event_id = 14
    AND entry_no = 1;

UPDATE entry
SET
    team_id = 5
WHERE
        event_id = 13
    AND entry_no = 5;

UPDATE entry
SET
    team_id = 5
WHERE
        event_id = 13
    AND entry_no = 3;

UPDATE entry
SET
    team_id = 5
WHERE
        event_id = 13
    AND entry_no = 4;

COMMIT;