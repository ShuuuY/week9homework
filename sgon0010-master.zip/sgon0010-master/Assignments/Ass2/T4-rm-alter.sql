--****PLEASE ENTER YOUR DETAILS BELOW****
--T4-rm-alter.sql

--Student ID:31519601
--Student Name:Shuyan Gong
--Unit Code:FIT2099
--Applied Class No:06

/* Comments for your marker:
-- No check constraint for official_role in OFFICIAL entity, 
since the list of roles may be expanded as required



*/

--4(a)
ALTER TABLE entry ADD entry_elapsedtime NUMBER(4, 2);

COMMENT ON COLUMN entry.entry_elapsedtime IS
    'entry_finishtime - entry_starttime';

/*4(b)*/
ALTER TABLE team DROP COLUMN char_id;

DROP TABLE team_char;

CREATE TABLE team_char (
    team_id        NUMBER(3) NOT NULL,
    char_id        NUMBER(3) NOT NULL,
    donation_ratio NUMBER(3) NOT NULL
);

COMMENT ON COLUMN team_char.team_id IS
    'Team identifier (unique)';

COMMENT ON COLUMN team_char.char_id IS
    'Charity unique identifier';

COMMENT ON COLUMN team_char.donation_ratio IS
    'The percentage of the donation that the team give to charity';

ALTER TABLE team_char ADD CONSTRAINT team_char_pk PRIMARY KEY ( team_id,
                                                                char_id );

ALTER TABLE team_char ADD CONSTRAINT team_char_uq UNIQUE ( team_id,
                                                           char_id );

ALTER TABLE team_char
    ADD CONSTRAINT chk_donation_ratio CHECK ( donation_ratio <= 100
                                              AND donation_ratio >= 0 );

ALTER TABLE team_char
    ADD CONSTRAINT team_char_team_fk FOREIGN KEY ( team_id )
        REFERENCES team ( team_id );

ALTER TABLE team_char
    ADD CONSTRAINT team_char_char_fk FOREIGN KEY ( char_id )
        REFERENCES charity ( char_id );
        
/*4(c)*/
DROP TABLE official;

CREATE TABLE official (
    comp_no       NUMBER(5) NOT NULL,
    carn_date     DATE NOT NULL,
    official_role VARCHAR2(30) NOT NULL
);

COMMENT ON COLUMN official.comp_no IS
    'Unique identifier for a competitor';

COMMENT ON COLUMN official.carn_date IS
    'Date of carnival (unique identifier)';

COMMENT ON COLUMN official.official_role IS
    'The role of the competitor in the carnival';

ALTER TABLE official ADD CONSTRAINT official_pk PRIMARY KEY ( comp_no,
                                                              carn_date );

ALTER TABLE official ADD CONSTRAINT team_char_uq UNIQUE ( comp_no,
                                                          carn_date );

ALTER TABLE official
    ADD CONSTRAINT official_competitor_fk FOREIGN KEY ( comp_no )
        REFERENCES competitor ( comp_no );

ALTER TABLE official
    ADD CONSTRAINT official_carnival_fk FOREIGN KEY ( carn_date )
        REFERENCES carnival ( carn_date );