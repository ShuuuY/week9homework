package game.Item;

import edu.monash.fit2099.engine.*;
import game.*;

/**
 * A class represents fruit.
 */
public class Fruit extends PortableItem implements Edible, EcoPointsTradable, EcoPointsValuable {

    private int age;
    private boolean isRipe = false;
    private boolean harvested = false;

    /**
     * Constructor
     *
     * @param isOnTree true if the fruit grow from tree.
     */
    public Fruit(boolean isOnTree) {
        super("Fruit",'f');
        this.age = 0;
        initFruitCapabilities(isOnTree);
    }

    /**
     * Helper method to add capabilities to fruits.
     *
     * @param isOnTree true if the fruit grow from tree, false if the fruit grow from bush.
     */
    private void initFruitCapabilities(boolean isOnTree) {
        if (isOnTree)
            this.addCapability(ItemCapabilities.TALL);
        else
            this.addCapability(ItemCapabilities.SHORT);
    }

    /**
     * Remove this fruit from its current location after it's eaten.
     */
    @Override
    public void removeEdibleFromLocation() {
            this.addCapability(ItemCapabilities.REMOVABLE_FROM_GAME);
    }

    /**
     * Inform a Fruit on the ground of the passage of time.
     * This method is called once per turn, if the fruit rests upon the ground.
     *
     * @param location current location of the fruit.
     */
    @Override
    public void tick(Location location) {
        super.tick(location);

        boolean isTall = this.hasCapability(ItemCapabilities.TALL);
        boolean isShort = this.hasCapability(ItemCapabilities.SHORT);
        boolean isOnGround = this.hasCapability(ItemCapabilities.ON_GROUND);
        boolean removableFromGame = this.hasCapability(ItemCapabilities.REMOVABLE_FROM_GAME);

        if (removableFromGame || (isOnGround && age >= 25))
            location.removeItem(this);
        else if (!isTall && !isShort) // DropItemAction by player :: fruit no TALL or SHORT state.
            this.addCapability(ItemCapabilities.ON_GROUND);
        else if (isRipe && Utility.getRandomInt(0, 100) < 5) {
            if (this.hasCapability(ItemCapabilities.TALL))
                Application.ecoPointManager.addEcoPoints(this);
            this.removeCapability(ItemCapabilities.TALL);
            this.removeCapability(ItemCapabilities.SHORT);
            this.addCapability(ItemCapabilities.ON_GROUND);
            location.addItem(this);
        }

        age++;
        if (age == 10)
            isRipe = true;
    }

    /**
     * Inform a carried fruit of the passage of time.
     *
     * @param currentLocation The location of the actor carrying this Item.
     * @param actor The actor carrying this Item.
     */
    @Override
    public void tick(Location currentLocation, Actor actor) {
        super.tick(currentLocation, actor);
        if (this.hasCapability(ItemCapabilities.REMOVABLE_FROM_GAME))
            actor.removeItemFromInventory(this);
    }

    /**
     *
     * @return PickFruitAction class to pick up the fruit.
     */
    @Override
    public PickUpItemAction getPickUpAction() {
        return new PickFruitAction(this);
    }

    /**
     * An action to pick up fruit.
     */
    private class PickFruitAction extends PickUpItemAction {

        /**
         * Constructor
         *
         * @param fruit the fruit that want to pick uo
         */
        public PickFruitAction(Fruit fruit) {
            super(fruit);
        }

        /**
         * Invoked to execute a {@code PickFruitAction} and
         * describe the action suitable for displaying in the UI menu.
         *
         * @param actor The actor performing the action.
         * @param map The map the actor is on.
         * @return a string which can differentiate pick up or not.
         */
        @Override
        public String execute(Actor actor, GameMap map) {
            if (actor instanceof Player) {
                boolean isTall = Fruit.this.hasCapability(ItemCapabilities.TALL);
                boolean isShort = Fruit.this.hasCapability(ItemCapabilities.SHORT);

                if ((isTall || isShort) && Utility.getRandomInt(0, 10) < 6)
                    return "Player fails to pick the fruit from tree or bush";
                else {
                    age = 0;
                    harvested = true;
                    Application.ecoPointManager.addEcoPoints(Fruit.this);
                    int gainedPoints = Fruit.this.getEcoPointsValue();
                    Fruit.this.removeCapability(ItemCapabilities.SHORT);
                    Fruit.this.removeCapability(ItemCapabilities.TALL);
                    super.execute(actor, map);
                    return "Player picked up the " + (isRipe ? "ripe" : "unripe") + " fruit and gained " + gainedPoints + " points.";
                }
            }
            else
                return actor + " does nothing.";
        }

        /**
         * Invoked by the game engine should the {@code PickFruitAction}
         * is a possible option for the player and describe the action suitable for displaying in the UI menu.
         *
         * @param actor The actor performing the action.
         * @return a string to display where actor to pick the fruit.
         */
        @Override
        public String menuDescription(Actor actor) {
            if (Fruit.this.hasCapability(ItemCapabilities.TALL))
                return actor + " try to pick the fruit from tree";
            else if (Fruit.this.hasCapability(ItemCapabilities.ON_GROUND))
                return actor + " picks up the fruit from ground";
            else
                return actor + " try to pick the fruit from bush";
        }
    }

    /**
     * @return The eco points needed to buy a unit of Fruit object.
     */
    @Override
    public int getEcoPointsExchangePrice() {
        return VendingMachine.getEcoPointsToBuy(Fruit.class);
    }

    /**
     * @return The eco points that shall be credited to the Player
     * based on each successful action of the Fruit such as a tree producing a fruit, a fruit turns ripe etc.
     */
    @Override
    public int getEcoPointsValue() {
        boolean isTall = this.hasCapability(ItemCapabilities.TALL);
        boolean isShort = this.hasCapability(ItemCapabilities.SHORT);
        if (harvested && (isTall || isShort) && isRipe)
            return 10;
        else if (isTall && isRipe)
            return 1;
        else
            return 0;
    }
}


