package game.Item;

import edu.monash.fit2099.engine.Action;
import edu.monash.fit2099.engine.Item;
import edu.monash.fit2099.engine.Location;
import game.Utility;

import java.util.List;

/**
 * A class represents Bush.
 */
public class Bush extends Item {

    /**
     * A Bush object is able to grow a {@code Fruit} object.
     */
    private Fruit fruit;

    /**
     * Constructor
     */
    public Bush() {
        super("Bush",'b',false);
    }

    /**
     * Grow a fruit and check if the fruit dropped.
     *
     * @param location The location of the bush
     */
    @Override
    public void tick(Location location) {
        super.tick(location);
        if (fruit != null) {
            fruit.tick(location);
            if (fruit.hasCapability(ItemCapabilities.ON_GROUND)) // fruit no longer belongs to the bush.
                fruit = null;
        }

        if ((fruit == null) && (Utility.getRandomInt(0,100) < 10))
            fruit = new Fruit(false);
    }

    /**
     *  Returns an unmodifiable copy of the actions list so that calling methods won't
     *  be able to change what bush can do without the Bush checking.
     *
     * @return an unmodifiable list of Actions
     */
    @Override
    public List<Action> getAllowableActions() {
        this.allowableActions.clear();
        if (fruit != null && fruit.hasCapability(ItemCapabilities.SHORT))
            this.allowableActions.add(fruit.getPickUpAction());
        return super.getAllowableActions();
    }
}
