package game.Item;

/**
 * A class represents capabilities of objects.
 */
public enum ItemCapabilities {
    TALL, SHORT, ON_GROUND, REMOVABLE_FROM_GAME, WATER
}
