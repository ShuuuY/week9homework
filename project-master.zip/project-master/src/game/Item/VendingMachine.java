package game.Item;

import edu.monash.fit2099.engine.*;
import game.Application;
import game.DinosaurSystem.*;
import game.DinosaurSystem.DinosaurEggs.AllosaurEgg;
import game.DinosaurSystem.DinosaurEggs.BrachiosaurEgg;
import game.DinosaurSystem.DinosaurEggs.PterodactylsEgg;
import game.DinosaurSystem.DinosaurEggs.StegosaurEgg;
import game.DinosaurSystem.MealKits.CarnivoreMealKit;
import game.DinosaurSystem.MealKits.VegetarianMealKit;
import game.EcoPointsTradable;
import game.Player;
import game.Utility;

import java.util.List;

/**
 * A class represents vending machine.
 */
public class VendingMachine extends Item {

    /**
     * The current location of the VendingMachine.
     */
    private Location location;

    /**
     * A nested enum class represents all objects that can be bought.
     *
     */
    public enum SellableItems {
        CARNIVORE_MEAL_KIT(CarnivoreMealKit.class, 500),
        VEGETARIAN_MEAL_KIT(VegetarianMealKit.class, 100),

        STEGOSAUR_EGG(StegosaurEgg.class, DinosaurSpecies.STEGOSAUR.EGG_BUY_ECO_POINTS),
        BRACHIOSAUR_EGG(BrachiosaurEgg.class, DinosaurSpecies.BRACHIOSAUR.EGG_BUY_ECO_POINTS),
        ALLOSAUR_EGG(AllosaurEgg.class, DinosaurSpecies.ALLOSAUR.EGG_BUY_ECO_POINTS),
        PTERODACTYLS_EGG(PterodactylsEgg.class, DinosaurSpecies.PTERODACTYLS.EGG_BUY_ECO_POINTS),

        LASER_GUN(LaserGun.class, 500),

        FRUIT(Fruit.class, 30);

        /**
         * The EcoPoints needed to buy a unit of the item from the vending machine.
         */
        public final int ECO_POINTS;

        /**
         * A Java.lang.Class type which implements {@code EcoPointsTradable} interface.
         *
         * @see game.EcoPointsTradable
         */
        public final Class<? extends EcoPointsTradable> CLASS_NAME;

        /**
         * An instance to put into the player's inventory by the vending machine when player buys it.
         */
        private EcoPointsTradable DEFAULT_INSTANCE;

        /**
         * Constructor.
         *
         * @param className any class that implements EcoPointsTradable interface.
         * @param ecoPoints the EcoPoints of the object.
         */
        SellableItems(Class<? extends EcoPointsTradable> className, int ecoPoints) {
            this.ECO_POINTS = ecoPoints;
            this.CLASS_NAME = className;
        }
    }

    /**
     * Constructor.
     *
     * @param name the name of the object that can be bought.
     * @param location location of VendingMachine
     * @param map the map that VendingMachine on.
     */
    public VendingMachine(String name, Location location, GameMap map) {
        super(name, 'V', false);
        this.location = location;
    }

    /**
     * Getter
     * @param class_name any class that extends EcoPointsTradable.
     * @return the EcoPoints of the object that player wants to buy.
     */
    public static int getEcoPointsToBuy(Class<? extends EcoPointsTradable> class_name) {
        for (SellableItems item : SellableItems.values()) {
            if (item.CLASS_NAME == class_name)
                return item.ECO_POINTS;
        }
        return 0; // class_name is not included inside SellableItems.
    }

    /**
     * Helper method. When a player gets near the VendingMachine, initialize a series of BuyAction objects.
     * @param player The player near the VendingMachine.
     */
    private void initAllowableActions(Player player) {
        SellableItems.ALLOSAUR_EGG.DEFAULT_INSTANCE = new AllosaurEgg( new Allosaur(
                DinosaurSpecies.ALLOSAUR.ADULT_MAX_HEALTH,
                DinosaurSpecies.ALLOSAUR.ADULT_MAX_HEALTH,
                Utility.getRandomGender()));

        SellableItems.BRACHIOSAUR_EGG.DEFAULT_INSTANCE = new BrachiosaurEgg(new Brachiosaur(
                DinosaurSpecies.BRACHIOSAUR.ADULT_MAX_HEALTH,
                DinosaurSpecies.BRACHIOSAUR.ADULT_MAX_HEALTH,
                Utility.getRandomGender()));

        SellableItems.STEGOSAUR_EGG.DEFAULT_INSTANCE = new StegosaurEgg(new Stegosaur(
                DinosaurSpecies.STEGOSAUR.ADULT_MAX_HEALTH,
                DinosaurSpecies.STEGOSAUR.ADULT_MAX_HEALTH,
                Utility.getRandomGender()));

        SellableItems.PTERODACTYLS_EGG.DEFAULT_INSTANCE = new PterodactylsEgg(new Pterodactyls(
                DinosaurSpecies.STEGOSAUR.ADULT_MAX_HEALTH,
                DinosaurSpecies.STEGOSAUR.ADULT_MAX_HEALTH,
                Utility.getRandomGender())
        );

        SellableItems.CARNIVORE_MEAL_KIT.DEFAULT_INSTANCE = new CarnivoreMealKit();
        SellableItems.VEGETARIAN_MEAL_KIT.DEFAULT_INSTANCE = new VegetarianMealKit();

        SellableItems.LASER_GUN.DEFAULT_INSTANCE = new LaserGun();

        SellableItems.FRUIT.DEFAULT_INSTANCE = new Fruit(false);

        this.allowableActions.clear();
        for (SellableItems item : SellableItems.values()) {
            this.allowableActions.add(new BuyAction(item.DEFAULT_INSTANCE));
        }
    }

    /**
     * A nested class to represents BuyAction.
     */
    private class BuyAction extends Action {

        private EcoPointsTradable item;

        /**
         * Constructor.
         *
         * @param item the object that player wants to buy.
         */
        public BuyAction(EcoPointsTradable item) {
            this.item = item;
        }

        /**
         * Invoked to execute a {@code BuyAction}.
         *
         * Display a message on console
         * @param actor The actor performing the action.
         * @param map The map the actor is on.
         * @return a string that shows if buy the item successfully.
         */
        @Override
        public String execute(Actor actor, GameMap map) {
            if (Application.ecoPointManager.subtractEcoPoints(item)) {
                actor.addItemToInventory((Item)item);
                return "Item has been added to your inventory & " + item.getEcoPointsExchangePrice()
                        + " has been deducted from your wallet.";
            }
            return "Not enough Eco Points in your wallet.";
        }

        /**
         * Invoked by the game engine should the {@code BuyAction}
         * is a possible option for the player and display the item's EcoPoints on console.
         *
         * @param actor The actor performing the action.
         * @return a string that shows the EcoPoints of an item
         */
        @Override
        public String menuDescription(Actor actor) {
            return "Buy " + item + " for " + item.getEcoPointsExchangePrice();
        }
    }

    /**
     * Returns an unmodifiable copy of the actions list so that calling methods won't
     * be able to change what vendingMachine can do without the VendingMachine checking.
     *
     * @return an unmodifiable list of Actions
     */
    @Override
    public List<Action> getAllowableActions() {
        Player player = null;
        for (Actor actor : Utility.findAllActorsAroundItem(location)) {
            if (actor instanceof Player) {
                player = (Player)actor;
                break;
            }
        }
        if (player != null)
            initAllowableActions(player);
        return allowableActions.getUnmodifiableActionList();
    }
}
