package game.Item;

import edu.monash.fit2099.engine.*;
import game.Edible;

/**
 * A class represents Fish.
 */
public class Fish extends Item implements Edible {

    /**
     * Constructor.
     *
     */
    public Fish() {
        super("Fish", '<', false);
        this.addCapability(ItemCapabilities.WATER);
    }

    /**
     * Remove fish from current location
     * @param currentLocation The location of the fish
     */
    @Override
    public void tick(Location currentLocation) {
        super.tick(currentLocation);
        if (this.hasCapability(ItemCapabilities.REMOVABLE_FROM_GAME)) {
            currentLocation.removeItem(this);
        }
    }

    /**
     * Remove this fish from its current location after it's eaten.
     */
    @Override
    public void removeEdibleFromLocation() {
        this.addCapability(ItemCapabilities.REMOVABLE_FROM_GAME);
    }

}