package game.Item;

import edu.monash.fit2099.engine.WeaponItem;
import game.DinosaurSystem.DinosaurSpecies;
import game.EcoPointsTradable;

/**
 * A class represents LaserGun.
 */
public class LaserGun extends WeaponItem implements EcoPointsTradable {

    /**
     * Constructor
     *
     */
    public LaserGun() {
        super("Laser Gun", 'l', DinosaurSpecies.STEGOSAUR.ADULT_MAX_HEALTH, "shoots");
    }

    /**
     * @return the EcoPoints needed to buy a unit of LaserGun.
     */
    @Override
    public int getEcoPointsExchangePrice() {
        return VendingMachine.getEcoPointsToBuy(this.getClass());
    }
}
