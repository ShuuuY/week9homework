package game.Item;

import edu.monash.fit2099.engine.*;
import game.Action.LifeCycleChangeAction;
import game.DinosaurSystem.Dinosaur;
import game.Edible;

/**
 * A class represents corpse.
 */
public class Corpse extends PortableItem implements Edible {

    /**
     * The {@code Actor} class of the corpse. i.e: A Pterodactyls corpse, stored as Pterodactyls.class
     */
    public final Class<? extends Actor> ACTOR_CLASS;
    private int corpseRemainingTurns;
    private int corpseLife;

    /**
     * Private constructor.
     * @param actor Actor to turn to a corpse.
     */
    private Corpse(Actor actor) {
        super("dead " + actor, '%');
        ACTOR_CLASS = actor.getClass();
        this.addCapability(ItemCapabilities.ON_GROUND);
        if (actor instanceof Dinosaur) {
            corpseRemainingTurns = ((Dinosaur)actor).getSpecies().CORPSE_ON_GROUND_TIME;
            corpseLife = ((Dinosaur) actor).getMaxHitPoints();
        }
    }

    /**
     * Static factory method to create corpse objects.
     *
     * @param actor who would turn into corpse
     * @param map the current location of corpse
     * @return a new corpse on the map
     */
    public static Corpse turnActorToCorpse(Actor actor, GameMap map) {
        Corpse corpse = new Corpse(actor);
        corpse.actorToCorpse(actor, map);
        return corpse;
    }

    /**
     * Helper method to handle typical actions when the actor gets turned into a corpse
     * such as drop all the items in the inventory.
     * @param actor Actor to turn to a corpse.
     * @param map The map which the actor belongs to.
     */
    private void actorToCorpse(Actor actor, GameMap map) {
        map.locationOf(actor).addItem(this);

        Actions dropActions = new Actions();
        for (Item item : actor.getInventory())
            dropActions.add(item.getDropAction());
        for (Action drop : dropActions)
            drop.execute(actor, map);
        map.removeActor(actor);
        actor.addCapability(LifeCycleChangeAction.LifeCycleChange.DEAD);
    }

    /**
     * Inform a carried Corpse of the passage of time.
     * This method is called once per turn, if the Corpse is being carried.
     *
     * @param currentLocation The location of the actor carrying the corpse.
     * @param actor The actor carrying this Corpse
     **/
    @Override
    public void tick(Location currentLocation, Actor actor) {
        decrementRemainingTurns();
        if (corpseLife <= 0 || this.hasCapability(ItemCapabilities.REMOVABLE_FROM_GAME))
            currentLocation.removeItem(this);
    }

    /**
     * Inform an Corpse on the ground of the passage of time.
     * This method is called once per turn, if the Corpse rests upon the ground.
     *
     * @param currentLocation The location of the ground on which we lie.
     */
    @Override
    public void tick(Location currentLocation) {
        decrementRemainingTurns();
        if (corpseLife <= 0 || this.hasCapability(ItemCapabilities.REMOVABLE_FROM_GAME))
            currentLocation.removeItem(this);
    }

    private void decrementRemainingTurns() {
        if (corpseRemainingTurns == 0)
            removeEdibleFromLocation();
        else
            corpseRemainingTurns--;
    }

    /**
     * Decrease the corpse's life.
     * @param decrement How much "corpse health" to decrease.
     */
    public void decrementCorpseLife(int decrement) {
        corpseLife -= decrement;
    }

    /**
     * Remove from current location if the Corpse disappeared(eaten,picked or exited).
     *
     */
    @Override
    public void removeEdibleFromLocation() {
        this.addCapability(ItemCapabilities.REMOVABLE_FROM_GAME);
    }

    /**
     * Getter for actor who is turned into corpse.
     *
     * @return CorpseType
     */
    public Class<? extends Actor> typeOfCorpse() {
        return ACTOR_CLASS;
    }
}
