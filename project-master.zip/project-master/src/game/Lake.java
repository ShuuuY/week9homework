package game;

import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.Ground;
import edu.monash.fit2099.engine.Location;
import game.Item.Fish;
import game.Item.ItemCapabilities;

/**
 * A class to display Lake on the ground
 */
public class Lake extends Ground implements Fertile {

    public int noOfFish;
    public double volume;
    public int age;

    /**
     * Constructor.
     */
    public Lake() {
        super('~');
        noOfFish = 5;
        volume = 25;
        age = 0;
    }

    /**
     * Check if the actor can enter Lake.
     *
     * @param actor the Actor to check
     * @return true if the actor can enter the lake.
     */
    @Override
    public boolean canActorEnter(Actor actor) {
        return actor.hasCapability(ItemCapabilities.WATER);
    }

    /**
     * call growFish() every turn if noOfFish < 25.
     *
     * @param location The location of the Lake
     */
    public void tick(Location location) {
        super.tick(location);
        if (noOfFish < 25) {
            growFish();
        }
    }

    /**
     * Each turn has a 60% chance of getting an extra fish
     */
    public void growFish() {
        if (Utility.getRandomInt(0, 10) < 6)
            noOfFish++;
    }

    /**
     * Calculate the rainfall and add to the volume of the lake.
     */
    public void increaseCapacity(double rainfall) {
        volume += rainfall * 20;
    }

    /**
     * A method to decrement the number of fish in the lake,
     * and return a fish for Pterodactyls to eat.
     *
     * @return a fish should be eaten.
     */
    @Override
    public Edible getProduce() {
        if (noOfFish > 0) {
            noOfFish--;
            return new Fish();
        }
        return null;
    }
}


