package game;

import edu.monash.fit2099.engine.*;
import game.DinosaurSystem.Dinosaur;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.function.Predicate;

/**
 * A utility class which contains some useful generic methods.
 */
public class Utility {

    /**
     * @param itemLocation The {@code Location} to look around for {@code Actor}.
     * @return A {@code List} of {@code Actor} around the given {@code location}.
     */
    public static List<Actor> findAllActorsAroundItem(Location itemLocation) {
        List<Actor> actors = new ArrayList<>();
        actors.add(itemLocation.getActor());
        for(Exit exit : itemLocation.getExits()) {
            Location exitLocation = exit.getDestination();
            actors.add(exitLocation.getActor());
        }
        return actors;
    }

    /**
     * @param startAt Inclusive. Generated integer starts from this number.
     * @param stopAt Exclusive. Generated integer always be less than this number.
     * @return A random generated integer.
     */
    public static int getRandomInt(int startAt, int stopAt) {
        Random random = new Random();
        return random.nextInt(stopAt - startAt) + startAt;
    }

    /**
     * @return A random {@code Gender}.
     *
     * @see game.DinosaurSystem.Dinosaur.Gender
     */
    public static Dinosaur.Gender getRandomGender() {
        return (Utility.getRandomInt(0, 2) == 0) ? Dinosaur.Gender.MALE : Dinosaur.Gender.FEMALE;
    }

    /**
     * Calculate the Euclidean distance between two given {@code Location} points.
     * @param from Starting {@code Location} point. Inclusive.
     * @param to Ending {@code Location} point. Inclusive.
     * @return The Euclidean distance between two given {@code Location} points.
     */
    public static long locationDistance(Location from, Location to) {
        return (long) Math.sqrt(Math.pow(from.x() - to.x(), 2) + Math.pow(from.y() - to.y(), 2));
    }

    /**
     * Search the adjacent locations of the given actor for "something" (specified by the caller).
     * If the condition is met, then return that location.
     * @param actor The actor whose adjacent locations to iterate through.
     * @param map The map where the actor belongs to.
     * @param tester The condition specifying whether the location being processed, around the actor,
     *               shall be returned.
     * @return The location, around the actor, where the condition is met.
     */
    public static Location searchAdjacentLocations(Actor actor, GameMap map, Predicate<Location> tester) {
        Location actorLocation = map.locationOf(actor);
        return searchAdjacentLocations(actorLocation, tester);
    }

    /**
     * Search the adjacent locations of the given location for "something" (specified by the caller).
     * If the condition is met, then return that location.
     * @param location The location whose adjacent locations to iterate through.
     * @param tester The condition specifying whether the location being processed, around the argument location,
     *               shall be returned.
     * @return The location, around the argument location, where the condition is met.
     */
    public static Location searchAdjacentLocations(Location location, Predicate<Location> tester) {
        for (Exit exit : location.getExits()) {
            Location destinationLocation = exit.getDestination();
            if (tester.test(destinationLocation))
                return destinationLocation;
        }
        return null;
    }

    /**
     * Given a map, iterate through every one of its locations and return those locations who meet the condition.
     * @param map The map whose locations to be iterated over.
     * @param tester The condition specifying whether the location being processed shall be returned.
     * @return A list of locations satisfying the argument condition.
     */
    public static List<Location> searchEntireMap(GameMap map, Predicate<Location> tester) {
        List<Location> validLocations = new ArrayList<>();

        for (int y : map.getYRange()) {
            for (int x : map.getXRange()) {
                Location location = map.at(x, y);
                if (tester.test(location))
                    validLocations.add(location);
            }
        }

        return validLocations;
    }
}
