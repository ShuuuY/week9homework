package game.Behaviour;

import edu.monash.fit2099.engine.*;
import game.Action.MateAction;
import game.DinosaurSystem.Dinosaur;
import game.Utility;

/**
 * Represents a Mating behaviour of an {@code Actor}.
 *
 * An {@code actor} who wants to mate will look for mate partner and if there is any on game map,
 * will move to their mate partner and then execute a {@code MateAction}.
 *
 * @see game.Action.MateAction
 */
public class Mating implements Behaviour {

    /**
     * What will the {@code actor} do if it has this {@code Mating} behaviour.
     * @param actor the Actor acting
     * @param map the GameMap containing the Actor
     * @return The next action the {@code Actor} will do.
     */
    @Override
    public Action getAction(Actor actor, GameMap map) {
        Location mateLocation = Utility.searchAdjacentLocations(actor, map,
                (location) -> {
                    Actor anotherActor = location.getActor();
                    return (actor instanceof Dinosaur && ((Dinosaur)actor).canMate(anotherActor, map));
                });

        if (mateLocation != null)
            return new MateAction(mateLocation.getActor().toString());

        return null;
    }
}
