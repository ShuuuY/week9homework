package game.Behaviour;

import edu.monash.fit2099.engine.*;
import game.*;
import game.DinosaurSystem.Dinosaur;
import game.Action.EatAction;
import game.Action.*;

/**
 * Represents a Hungry behaviour of an {@code Actor}.
 *
 * An {@code actor} who feels hungry will look for food source and if there is any on game map,
 * will move to their the food source and then execute an {@code EatAction}.
 *
 * @see game.Action.EatAction
 */
public class Hungry implements Behaviour {

    /**
     * What will the {@code actor} do if it has this {@code Hungry} behaviour.
     * @param actor the Actor acting
     * @param map the GameMap containing the Actor
     * @return The next action the {@code Actor} will do.
     */
    @Override
    public Action getAction(Actor actor, GameMap map) {
        if (!(actor instanceof Dinosaur))
            return null;

        Location actorLocation = map.locationOf(actor);
        System.out.println(actor + " at " + actorLocation.x() + "," + actorLocation.y() + " is getting hungry");

        // Check if food is right on the location where actor is standing
        Edible food = getFoodFromLocation(actor, map.locationOf(actor));
        if (food != null)
            return new EatAction(food);

        // Check if there is any food around the actor
        Location foodLocation = Utility.searchAdjacentLocations(actor, map,
                (location) -> {

                    if (!location.canActorEnter(actor))
                        return false;

                    for (Item item : location.getItems()) {
                        if (item instanceof Edible && ((Dinosaur) actor).isEdible((Edible)item))
                            return true;
                    }

                    if (location.getGround() instanceof Fertile) {
                        Edible groundFood = ((Fertile)location.getGround()).getProduce();
                        return (groundFood != null) && ((Dinosaur) actor).isEdible(groundFood);
                    }
                    return false;
                });

        // there is a food location found, search for food at that location
        if (foodLocation != null) {
            food = getFoodFromLocation(actor, foodLocation);

            if (food != null)
                return new ChainedMoveActorAction(foodLocation, "towards " + food,
                        new EatAction(food));
        }

        // there is no food available for the actor
        return null;
    }

    /**
     * Helper method to retrieve a food from a given location.
     * @param actor The actor who is going to eat the food.
     * @param location The location where the food is at.
     * @return An edible food or null if there isn't any.
     */
    private Edible getFoodFromLocation(Actor actor, Location location) {
        Edible food = null;
        Dinosaur dinosaur = (Dinosaur)actor;

        // either the food is an item sitting on the location or it's from the ground (i.e: fruit)
        for (Item item : location.getItems()) {
            if (item instanceof Edible && dinosaur.isEdible((Edible)item)) {
                food = (Edible)item;
                break;
            }
        }

        // if it's still null, then it can only be food from ground type objects
        if ((food == null) && location.getGround() instanceof Fertile) {
            food = ((Fertile) location.getGround()).getProduce();
            if (!(dinosaur.isEdible(food)))
                food = null;
        }

        return food;
    }
}
