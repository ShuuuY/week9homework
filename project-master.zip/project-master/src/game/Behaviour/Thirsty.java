package game.Behaviour;

import edu.monash.fit2099.engine.Action;
import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.GameMap;
import edu.monash.fit2099.engine.Location;
import game.Action.DrinkAction;
import game.DinosaurSystem.Dinosaur;
import game.Lake;
import game.Utility;

/**
 * Represents a Thirsty behaviour of an {@code Actor}.
 *
 * An {@code actor} who feels thirsty will look for water source and if there is any on game map,
 * will move to their the water source and then execute a {@code DrinkAction}.
 *
 * @see game.Action.DrinkAction
 */
public class Thirsty implements Behaviour{

    /**
     * What will the {@code actor} do if it has this {@code Thirsty} behaviour.
     * @param actor the Actor acting
     * @param map the GameMap containing the Actor
     * @return The next action the {@code Actor} will do.
     */
    @Override
    public Action getAction(Actor actor, GameMap map) {
        Location actorLocation = map.locationOf(actor);
        System.out.println(actor + " at " + actorLocation.x() + "," + actorLocation.y() + " is getting thirsty");

        Location lakeLocation = Utility.searchAdjacentLocations(actor, map,
                (location) -> location.getGround() instanceof Lake);

        if (lakeLocation != null && actor instanceof Dinosaur)
            return new DrinkAction(((Dinosaur) actor).getSpecies().DEFAULT_DRINK_WATER_LEVEL_INCREASE);

        return null;
    }
}
