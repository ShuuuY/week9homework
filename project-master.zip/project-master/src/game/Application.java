package game;

import java.util.Arrays;
import java.util.List;

import edu.monash.fit2099.engine.*;
import game.DinosaurSystem.*;
import game.Item.VendingMachine;

/**
 * The main class for the Jurassic World game.
 *
 */
public class Application {

	/**
	 * The manager object responsible to manage the player's eco points during the game.
	 */
	public static EcoPointManager ecoPointManager;

	/**
	 * Entry point to the execution of the game.
	 * @param args Console line arguments.
	 */
	public static void main(String[] args) {
		Display display = new Display();
		char command;
		do {
			System.out.println("1.Challenge");
			System.out.println("2.Sandbox");
			System.out.println("0.Quit");
			command = display.readChar();
			if (command == '1') {
				challengeOption(display);
			} else if (command == '2') {
				initGame(null);
			}
		} while (command != '0');
		System.out.println("Application Closed.");
	}

	/**
	 * Initializes the game with game maps, actors and run the game.
	 * @param challenge Type of game challenge the player has chosen from the console.
	 */
	public static void initGame(Challenge challenge) {
		World world = new GameWorld(new Display());

		FancyGroundFactory groundFactory = new FancyGroundFactory(new Dirt(), new Wall(), new Floor(), new Tree(), new Lake());

		List<String> south = Arrays.asList(
				"................................................................................",
				"................................~...............................................",
				".....#######....................................................................",
				".....#_____#....................................................................",
				".....#_____#....................................................................",
				".....###.###.............~......................................................",
				"................................................................................",
				"......................................+++.......................................",
				".......................................++++.....................................",
				"...................................+++++...........................~............",
				".....................................++++++.....................................",
				"......................................+++.......................................",
				"..........~..........................+++........................................",
				"................................................................................",
				"............+++.................................................................",
				".............+++++..............................................................",
				"...............++........................................+++++..................",
				".............+++.........................~..........++++++++....................",
				"............+++.......................................+++.......................",
				".............~..................................................................",
				".........................................................................++.....",
				".....................................................~..................++.++...",
				"..............~..........................................................++++...",
				"..........................................................................++....",
				"................................................................................");
		List<String> north = Arrays.asList(
				"................................................................................",
				"................................................................................",
				"................................................................................",
				".....#_____#....................................................................",
				".....#_____#....................................................................",
				".....###.###.............~......................................................",
				"................................................................................",
				"......................................+++.......................................",
				".......................................++++.....................................",
				"................................................................................",
				"................................................................................",
				"......................................+++.......................................",
				"..........~..........................+++........................................",
				"................................................................................",
				"............+++.................................................................",
				".............+++++..............................................................",
				"...............++........................................+++++..................",
				".............+++.........................~..........++++++++....................",
				"................................................................................",
				"................................................................................",
				"................................................................................",
				"................................................................................",
				"................................................................................",
				"................................................................................",
				"................................................................................");
		ConnectMap southMap = new ConnectMap(groundFactory, south);
		ConnectMap northMap = new ConnectMap(groundFactory, north);
		southMap.setNorth(northMap);
		northMap.setSouth(southMap);
		southMap.buildMapComplete();
		northMap.buildMapComplete();

		world.addGameMap(southMap);
		world.addGameMap(northMap);

		Player player = new Player("Player", '@', 100);
		player.setChallenge(challenge);
		Application.ecoPointManager = new EcoPointManager(player);
		world.addPlayer(player, southMap.at(25, 12));

		// Place a vending machine
		southMap.at(24, 13).addItem(new VendingMachine("Vending Machine", new Location(southMap, 24, 13), southMap));

		// Place a pair of adult Stegosaurs in the map
		Stegosaur stegosaurFemale1 = new Stegosaur(
				100,
				DinosaurSpecies.STEGOSAUR.ADULT_MAX_HEALTH,
				Dinosaur.Gender.FEMALE);
		stegosaurFemale1.ageGroup = Dinosaur.AgeGroup.ADULT;

		Stegosaur stegosaurMale2 = new Stegosaur(
				100,
				DinosaurSpecies.STEGOSAUR.ADULT_MAX_HEALTH,
				Dinosaur.Gender.MALE);
		stegosaurMale2.ageGroup = Dinosaur.AgeGroup.ADULT;

//		 Place 2 pairs of ADULT, MALE & FEMALE Brachiosaur.
		Brachiosaur brachiosaurFemale1 = new Brachiosaur(
				100,
				DinosaurSpecies.BRACHIOSAUR.ADULT_MAX_HEALTH,
				Dinosaur.Gender.FEMALE);
		brachiosaurFemale1.ageGroup = Dinosaur.AgeGroup.ADULT;

		Brachiosaur brachiosaurFemale2 = new Brachiosaur(
				100,
				DinosaurSpecies.BRACHIOSAUR.ADULT_MAX_HEALTH,
				Dinosaur.Gender.FEMALE);
		brachiosaurFemale2.ageGroup = Dinosaur.AgeGroup.ADULT;

		Brachiosaur brachiosaurMale3 = new Brachiosaur(
				100,
				DinosaurSpecies.BRACHIOSAUR.ADULT_MAX_HEALTH,
				Dinosaur.Gender.MALE);
		brachiosaurMale3.ageGroup = Dinosaur.AgeGroup.ADULT;

		Brachiosaur brachiosaurMale4 = new Brachiosaur(
				100,
				DinosaurSpecies.BRACHIOSAUR.ADULT_MAX_HEALTH,
				Dinosaur.Gender.MALE);
		brachiosaurMale4.ageGroup = Dinosaur.AgeGroup.ADULT;

		// Place a pair of adult Pterodactyls. One female, one male.
		Pterodactyls pterodactyls1 = new Pterodactyls(
				70,
				DinosaurSpecies.PTERODACTYLS.ADULT_MAX_HEALTH,
				Dinosaur.Gender.MALE
		);
		pterodactyls1.ageGroup = Dinosaur.AgeGroup.ADULT;

		Pterodactyls pterodactyls2 = new Pterodactyls(
				70,
				DinosaurSpecies.PTERODACTYLS.ADULT_MAX_HEALTH,
				Dinosaur.Gender.FEMALE
		);
		pterodactyls2.ageGroup = Dinosaur.AgeGroup.ADULT;

		southMap.at(15, 17).addActor(stegosaurFemale1);
		southMap.at(16, 17).addActor(stegosaurMale2);
		southMap.at(72, 24).addActor(brachiosaurFemale1);
		southMap.at(20, 8).addActor(brachiosaurFemale2);
		southMap.at(40, 12).addActor(brachiosaurMale3);
		southMap.at(58, 10).addActor(brachiosaurMale4);

		// Both Pterodactyls on tree - test : mate + lay egg
		southMap.at(15,16).addActor(pterodactyls1);
		southMap.at(15,15).addActor(pterodactyls2);

		world.run();
	}

	/**
	 * Helper method to let the user choose level of difficulty if they choose to play the challenging mode.
	 * @param display The display to put on the prompts to communicate with the user.
	 */
	private static void challengeOption(Display display) {
		System.out.println("1.Limit: 1 steps 0 points");
		System.out.println("2.Limit: 5 steps 10 points");
		System.out.println("3.Limit: 10 steps 30 points");
		System.out.println("4.Limit: 30 steps 100 points");
		do {
			char command = display.readChar();
			if (command == '1') {
				initGame(new Challenge(1, 0));
				return;
			}
			if (command == '2') {
				initGame(new Challenge(5, 10));
				return;
			}
			if (command == '3') {
				initGame(new Challenge(10, 30));
				return;
			}
			if (command == '4') {
				initGame(new Challenge(30, 100));
				return;
			}
		} while (true);
	}
}

