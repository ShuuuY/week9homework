package game;

/**
 * A class for challenge mode game.
 */
public class Challenge {
    private int steps;
    private int point;

    /**
     * Constructor.
     *
     * @param steps total steps that the player choose.
     * @param point total points that the player choose.
     */
    public Challenge(int steps, int point) {
        this.steps = steps;
        this.point = point;
    }

    /**
     * Getter.
     *
     * @return total steps that the player choose.
     */
    public int getSteps() {
        return steps;
    }

    /**
     * Getter.
     *
     * @return total points that the player choose.
     */
    public int getPoint() {
        return point;
    }
}