package game;

import edu.monash.fit2099.engine.*;
import game.Action.AttackAction;
import game.Action.QuitGameAction;
import java.util.ArrayList;
import java.util.List;

/**
 * Class representing the Player.
 */
public class Player extends Actor {

	private Menu menu = new Menu();
	private int ecoPoints = 10000;
	private GameWorld world;
	private Challenge challenge;
	private int steps;
	private final int ORIGIN_POINT;

	/**
	 * Constructor.
	 *
	 * @param name        Name to call the player in the UI
	 * @param displayChar Character to represent the player in the UI
	 * @param hitPoints   Player's starting number of hitpoints
	 */
	public Player(String name, char displayChar, int hitPoints) {
		super(name, displayChar, hitPoints);
		ORIGIN_POINT = ecoPoints;
	}

	/**
	 * @param challenge The challenge that the player has chosen to play.
	 */
	public void setChallenge(Challenge challenge) {
		this.challenge = challenge;
	}

	/**
	 * @param world The game world where the player belongs to.
	 */
	public void setWorld(GameWorld world) {
		this.world = world;
	}

	/**
	 * Add EcoPoints and return true if increase EcoPoints successfully.
	 *
	 * @param increasePoints the EcoPoints that should be added.
	 * @return true if increase EcoPoints successfully.
	 */
	public boolean increaseEcoPoints(int increasePoints) {
		boolean isValid = increasePoints >= 0;
		if (isValid)
			ecoPoints += increasePoints;
		return isValid;
	}

	/**
	 * Add EcoPoints and return true if decrease EcoPoints successfully.
	 *
	 * @param decreasePoints the EcoPoints that should be decreased.
	 * @return true if decrease EcoPoints successfully.
	 */
	public boolean decreaseEcoPoints(int decreasePoints) {
		boolean isValid = false;
		if (decreasePoints >= 0 && ecoPoints >= decreasePoints) {
			isValid = true;
			ecoPoints -= decreasePoints;
		}
		return isValid;
	}

	/**
	 * Handle player's Action and return a player's Action
	 * @param actions    collection of possible Actions for this Actor
	 * @param lastAction The Action this Actor took last turn. Can do interesting things in conjunction with Action.getNextAction()
	 * @param map        the map containing the Actor
	 * @param display    the I/O object to which messages may be written
	 * @return an action and display on the console.
	 */
	@Override
	public Action playTurn(Actions actions, Action lastAction, GameMap map, Display display) {
		steps++;
		// Handle multi-turn Actions
		if (lastAction.getNextAction() != null)
			return lastAction.getNextAction();

		// If player has weapon, they can initiate attack actions
		WeaponItem weapon = (WeaponItem)searchInventory(WeaponItem.class);
		if (weapon != null)
			actions.add(getValidAttackActions(map, weapon));

		actions.add(new QuitGameAction());
		return menu.showMenu(this, actions, display);
	}

	/**
	 * Search the Item in player's inventory,and return it.
	 *
	 * @param className any Class that extends Item.
	 * @return an item if is in inventory
	 */
	private Item searchInventory(Class<? extends Item> className) {
		for (Item item : this.getInventory()) {
			if (className.isInstance(item))
				return item;
		}
		return null;
	}

	/**
	 * Helper method to get all the attack actions that this player can do all other actor objects on the same map.
	 * @param map The map where targets of the attack actions belongs to.
	 * @param weapon The weapon which the player will use to attack.
	 * @return A list of {@code AttackAction} objects executable by this player.
	 */
	private List<Action> getValidAttackActions(GameMap map, Weapon weapon) {
		List<Location> validLocations = Utility.searchEntireMap(map, Location::containsAnActor);
		List<Action> attackActions = new ArrayList<>();
		for (Location location : validLocations)
			attackActions.add(new AttackAction(location.getActor(), weapon));
		return attackActions;
	}

	/**
	 * Leave the game once the game is over.
	 */
	public void leaveGame() {
		if (world != null) {
			world.leaveWorld(GameWorld.GameStatus.QUIT);
		}
	}

	/**
	 * A method to determine the game status of the player by comparing current eco points
	 * with the target that the player choose at the beginning of the game.
	 *
	 * @return the game status of the player.
	 */
	public GameWorld.GameStatus calculateGameStatus() {
		if (challenge == null || steps < challenge.getSteps()) {
			return GameWorld.GameStatus.PLAYING;
		}
		if (challenge.getPoint() > (ecoPoints - ORIGIN_POINT)) {
			return GameWorld.GameStatus.LOSE;
		}
		return GameWorld.GameStatus.WIN;
	}
}
