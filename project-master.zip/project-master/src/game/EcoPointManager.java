package game;

/**
 * A class for expensing and getting EcoPoint.
 */
public class EcoPointManager {

    /**
     * The player that this EcoPointManager will manage.
     */
    private Player player;

    /**
     * Constructor assign the player
     *
     * @param player EcoPointManager help player manage with his/her EcoPoints.
     */
    public EcoPointManager(Player player) {
        this.player = player;
    }

    /**
     * Call increaseEcoPoints method in player class which return true if EcoPoints >= 0
     * and add the EcoPoints.
     *
     * @param valuableObj the object will increase the EcoPoints.
     * @return return true if player.increaseEcoPoints() return true.
     */
    public boolean addEcoPoints(EcoPointsValuable valuableObj) {
        return player.increaseEcoPoints(valuableObj.getEcoPointsValue());
    }

    /**
     * Call decreaseEcoPoints method in player class which return true if EcoPoints >= 0
     * and it is fewer than the EcoPoints that player owned now,the subtract the EcoPoints.
     *
     * @param tradableObj the object will decrease the EcoPoints.
     * @return return true if player.decreaseEcoPoints() return true.
     */
    public boolean subtractEcoPoints(EcoPointsTradable tradableObj) {
        return player.decreaseEcoPoints(tradableObj.getEcoPointsExchangePrice());
    }
}
