package game;

/**
 * An interface that all objects should implement if they produce Edible objects.
 */
public interface Fertile {

    /**
     * @return An Edible object from the fertile object since it produces Edible objects.
     */
    Edible getProduce();
}
