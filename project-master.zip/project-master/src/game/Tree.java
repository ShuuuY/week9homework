package game;

import edu.monash.fit2099.engine.Actions;
import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.Ground;
import edu.monash.fit2099.engine.Location;
import game.Item.Fruit;
import game.Item.ItemCapabilities;

/**
 *  A class that represents a Tree
 */
public class Tree extends Ground implements Fertile {

	/**
	 * A tree can grow a fruit.
	 */
	private Fruit fruit;

	/**
	 * Constructor
	 */
	public Tree() {
		super('+');
	}

	/**
	 * Grow a fruit and check if is dropped.
	 *
	 * @param location The location of the Tree
	 */
	@Override
	public void tick(Location location) {
		super.tick(location);
		displayChar = 'T';
		if (fruit != null) {
			fruit.tick(location);
			if (fruit.hasCapability(ItemCapabilities.ON_GROUND)) // fruit no longer belongs to the tree.
				fruit = null;
		}

		if ((fruit == null) && (Utility.getRandomInt(0,100) < 50))
			fruit = new Fruit(true);
	}

	/**
	 *
	 * @return A fruit grown on this tree. Null if it hasn't produced any.
	 */
	@Override
	public Edible getProduce() {
		return fruit;
	}

	/**
	 * Return action which probably is fruit.getPickUpAction()
	 *
	 * @param actor the Actor acting
	 * @param location the current Location
	 * @param direction the direction of the tree from the Actor
	 * @return a new collection of Actions
	 */
	@Override
	public Actions allowableActions(Actor actor, Location location, String direction) {
		Actions allowableActions = super.allowableActions(actor, location, direction);
		if (fruit != null && fruit.hasCapability(ItemCapabilities.TALL))
			allowableActions.add(fruit.getPickUpAction());
		return allowableActions;
	}
}
