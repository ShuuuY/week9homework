package game;

import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.Display;
import edu.monash.fit2099.engine.Location;
import edu.monash.fit2099.engine.World;

import static game.GameWorld.GameStatus.*;

/**
 * Class representing the new game world, including the locations of all Actors, the
 * player, the playing grid and game status.
 */
public class GameWorld extends World {

    /**
     * The current status of the game. One of : PLAYING, LOSE, WIN, QUIT.
     */
    GameStatus gameStatus;

    /**
     * The current player of the game.
     */
    Player player;

    /**
     * Constructor.
     *
     * @param display the Display will display this World.
     */
    public GameWorld(Display display) {
        super(display);
        gameStatus = PLAYING;
    }

    /**
     * Set an actor as the player. The map is drawn just before this Actor's turn
     *
     * @param player   the player to add
     * @param location the Location where the player is to be added
     */
    @Override
    public void addPlayer(Actor player, Location location) {
        super.addPlayer(player, location);
        if (player instanceof Player) {
            this.player = (Player) player;
            this.player.setWorld(this);
        }
    }

    /**
     * A method for player to leave the game world.
     *
     * @param gameStatus player current gameStatus
     */
    public void leaveWorld(GameStatus gameStatus) {
        this.gameStatus = gameStatus;
        actorLocations.remove(player);
    }

    /**
     * Display the game status message on the console after no remaining steps.
     *
     * @return the game status of the player after ending the game.
     */
    @Override
    protected String endGameMessage() {
        if (gameStatus == LOSE) {
            return "GAME LOSE.";
        } else if (gameStatus == WIN) {
            return "GAME WIN.";
        } else if (gameStatus == QUIT) {
            return "GAME QUIT.";
        }
        return super.endGameMessage();
    }

    /**
     * Check the gameStatus,if the game status is not PLAYING,
     * it will call leaveWorld()
     *
     * @param actor the Actor whose turn it is.
     */
    @Override
    protected void processActorTurn(Actor actor) {
        super.processActorTurn(actor);
        GameStatus gameStatus = player.calculateGameStatus();
        if (gameStatus == PLAYING) {
            return;
        }
        leaveWorld(gameStatus);
    }

    /**
     * Store the statuses' constants of the game.
     */
    public enum GameStatus {
        PLAYING, LOSE, WIN, QUIT
    }
}