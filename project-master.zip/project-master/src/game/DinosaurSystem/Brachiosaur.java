package game.DinosaurSystem;

import game.*;
import game.DinosaurSystem.DinosaurEggs.BrachiosaurEgg;
import game.DinosaurSystem.DinosaurEggs.DinosaurEgg;
import game.Item.ItemCapabilities;

/**
 * Represents an Brachiosaur in the game who is also of type Herbivore Dinosaur.
 */
public class Brachiosaur extends Dinosaur {

    /**
     * Number of Brachiosaur instances already been instantiated in the game.
     */
    private static int numOfInstances = 0;

    /**
     * The species of Brachiosaur.
     *
     * @see game.DinosaurSystem.DinosaurSpecies
     */
    public static final DinosaurSpecies SPECIES = DinosaurSpecies.BRACHIOSAUR;

    /**
     * Constructor.
     * @param startHitPoints Starting hit points of a new instantiated Brachiosaur.
     * @param maxHitPoints The maximum hit points the new instantiated Brachiosaur can go up to.
     * @param gender Gender of new instantiated Brachiosaur.
     */
    public Brachiosaur(int startHitPoints, int maxHitPoints, Gender gender) {
        super("Brachiosaur " + gender + " " + (numOfInstances + 1),
                'r', startHitPoints, maxHitPoints, gender);
        this.addCapability(ItemCapabilities.TALL); // all Brachiosaur can only eat fruits on trees.
        numOfInstances++;
    }

    /**
     * @param food The food fed to the dinosaur.
     * @return Extra energy gained by the {@code Brachiosaur} if it's fed.
     */
    @Override
    public int extraEnergyGainBeingFed(Edible food) {
        return 15;
    }

    /**
     * @param egg The egg to turn into a child dinosaur.
     * @return A child {@code Brachiosaur}.
     */
    @Override
    public Dinosaur hatchEggs(DinosaurEgg egg) {
        Dinosaur newBrachiosaur = new Brachiosaur(
                this.getSpecies().BABY_START_HEALTH,
                this.getSpecies().BABY_MAX_HEALTH,
                Utility.getRandomGender());
        return newBrachiosaur;
    }

    /**
     * @param embryo The embryo to turn into a dinosaur egg.
     * @return A new {@code BrachiosaurEgg}.
     */
    @Override
    public DinosaurEgg embryoToEgg(Embryo embryo) {
        return new BrachiosaurEgg(this);
    }

    /**
     * @return The species of {@code Brachiosaur}.
     */
    @Override
    public DinosaurSpecies getSpecies() {
        return SPECIES;
    }
}
