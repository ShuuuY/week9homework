package game.DinosaurSystem.MealKits;

import edu.monash.fit2099.engine.*;
import game.*;
import game.Action.FeedAction;
import game.DinosaurSystem.Dinosaur;
import game.Item.ItemCapabilities;
import game.Item.PortableItem;
import game.Item.VendingMachine;

import java.util.List;

/**
 * Represents a Meal Kit object which is a portable item.
 *
 * A meal kit object can be eat by dinosaur. Therefore it implements {@code Edible}.
 * A meal kit object can be bought from the vending machine. Therefore it implements {@code EcoPointsTradable}.
 *
 * @see game.EcoPointsTradable
 * @see game.Edible
 */
public abstract class MealKit extends PortableItem implements Edible, EcoPointsTradable {

    /**
     * The current location the meal kit object is at.
     */
    Location currentLocation;

    /**
     * Constructor.
     *
     * @param name Name of the {@code MealKit} object.
     */
    public MealKit(String name) {
        super(name, 'm');
    }

    /**
     * Invoked when this {@code MealKit} object eaten by an {@code Actor}.
     */
    @Override
    public void removeEdibleFromLocation() {
        this.addCapability(ItemCapabilities.REMOVABLE_FROM_GAME);
    }

    /**
     * A {@code MealKit} object is an item and can experience passage of time.
     * @param currentLocation The location of the actor carrying this Item.
     * @param actor The actor carrying this Item.
     */
    @Override
    public void tick(Location currentLocation, Actor actor) {
        super.tick(currentLocation, actor);
        if (this.hasCapability(ItemCapabilities.REMOVABLE_FROM_GAME))
            actor.removeItemFromInventory(this);
        else
            this.currentLocation = currentLocation;
    }

    /**
     * A {@code MealKit} object is an item and can experience passage of time.
     * @param currentLocation The location of the actor carrying this Item.
     */
    @Override
    public void tick(Location currentLocation) {
        super.tick(currentLocation);
        if (this.hasCapability(ItemCapabilities.REMOVABLE_FROM_GAME))
            currentLocation.removeItem(this);
        else
            this.currentLocation = currentLocation;
    }

    /**
     * @return The allowable actions that this {@code MealKit} object can do to other {@code Actor}.
     *
     * For example : feeding a {@code Dinosaur}.
     */
    @Override
    public List<Action> getAllowableActions() {
        this.allowableActions.clear();
        for (Actor actor : Utility.findAllActorsAroundItem(currentLocation)) {
            if (actor instanceof Dinosaur && canActorEatMealKit(actor)) {
                FeedAction feedAction
                        = new FeedAction(actor, this, 0, ((Dinosaur) actor).getMaxHitPoints());
                this.allowableActions.add(feedAction);
            }
        }
        return super.getAllowableActions();
    }

    /**
     * @return The required EcoPoints in order to purchase a single unit of this {@code MealKit} object
     * from the vending machine.
     */
    @Override
    public int getEcoPointsExchangePrice() {
        return VendingMachine.getEcoPointsToBuy(this.getClass());
    }

    /**
     * @param actor The {@code Actor} to test against.
     * @return True if the target {@code actor} can consume this {@code MealKit} object. False otherwise.
     */
    public abstract boolean canActorEatMealKit(Actor actor);
}
