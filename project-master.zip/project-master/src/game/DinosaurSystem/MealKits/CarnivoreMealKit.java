package game.DinosaurSystem.MealKits;

import edu.monash.fit2099.engine.Actor;
import game.DinosaurSystem.Allosaur;

/**
 * Represents a {@code MealKit} object that can be eaten only by {@code Carnivore Dinosaur}.
 */
public class CarnivoreMealKit extends MealKit {

    /**
     * Constructor.
     */
    public CarnivoreMealKit() {
        super("Carnivore Meal Kit");
    }

    /**
     * @param actor The {@code Actor} to test against.
     * @return True if the {@code actor} is of type {@code Carnivore}.
     */
    @Override
    public boolean canActorEatMealKit(Actor actor) {
        return (actor instanceof Allosaur);
    }
}
