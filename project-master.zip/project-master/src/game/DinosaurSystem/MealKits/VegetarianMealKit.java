package game.DinosaurSystem.MealKits;

import edu.monash.fit2099.engine.Actor;
import game.DinosaurSystem.Brachiosaur;
import game.DinosaurSystem.Stegosaur;

/**
 * Represents a {@code MealKit} object that can be eaten only by {@code Herbivore Dinosaur}.
 */
public class VegetarianMealKit extends MealKit {

    /**
     * Constructor.
     */
    public VegetarianMealKit() {
        super("Vegetarian Meal Kit");
    }

    /**
     * @param actor The {@code Actor} to test against.
     * @return True if the {@code actor} is of type {@code Herbivore}.
     */
    @Override
    public boolean canActorEatMealKit(Actor actor) {
        return (actor instanceof Stegosaur) || (actor instanceof Brachiosaur);
    }
}
