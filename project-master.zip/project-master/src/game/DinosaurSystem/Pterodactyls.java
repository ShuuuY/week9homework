package game.DinosaurSystem;

import edu.monash.fit2099.engine.*;
import game.DinosaurSystem.DinosaurEggs.DinosaurEgg;
import game.DinosaurSystem.DinosaurEggs.PterodactylsEgg;
import game.Edible;
import game.Item.Fish;
import game.Item.ItemCapabilities;
import game.Tree;
import game.Utility;

public class Pterodactyls extends Dinosaur {

    private static int numOfInstances = 0;

    /**
     * The species of Pterodactyls.
     *
     * @see game.DinosaurSystem.DinosaurSpecies
     */
    public static final DinosaurSpecies SPECIES = DinosaurSpecies.PTERODACTYLS;

    /**
     * Constructor.
     * @param startHitPoints Starting hit points of a newly instantiated Pterodactyls.
     * @param maxHitPoints The maximum hit points the newly instantiated Pterodactyls can go up to.
     * @param gender Gender of newly instantiated Pterodactyls.
     */
    public Pterodactyls(int startHitPoints, int maxHitPoints, Gender gender) {
        super("Pterodactyls " + gender + " " + (numOfInstances + 1),
                'p', startHitPoints, maxHitPoints, gender);
        numOfInstances++;
        this.addCapability(ItemCapabilities.WATER);
    }

    /**
     * Invoke by the game engine when it's turn for the dinosaur to act.
     * @param actions Actions that the {@code Pterodactyls} can potentially take.
     * @param lastAction The last action that the {@code Pterodactyls} took.
     * @param map The GameMap in which the {@code Pterodactyls} belongs to.
     * @param display The display which contains the {@code Pterodactyls}.
     * @return The selected action by the {@code Pterodactyls} based on a series of criteria.
     */
    @Override
    public Action playTurn(Actions actions, Action lastAction, GameMap map, Display display) {
        this.updateCapabilities(map.locationOf(this));
        return super.playTurn(actions, lastAction, map, display);
    }

    /**
     * @param food The food ate by the dinosaur.
     * @return The energy gained by the dinosaur when it consumes that {@code food}.
     */
    @Override
    public int energyGainFromFood(Edible food) {
        if (food instanceof Fish)
            return 5;
        return super.energyGainFromFood(food);
    }

    /**
     * @param food The food fed to the dinosaur.
     * @return Extra energy gained by the {@code Pterodactyls} if it's fed.
     */
    @Override
    public int extraEnergyGainBeingFed(Edible food) {
        return 10;
    }

    /**
     * @param egg The egg to turn into a child dinosaur.
     * @return A child {@code Pterodactyls}.
     */
    @Override
    public Dinosaur hatchEggs(DinosaurEgg egg) {
        Dinosaur newPterodactyls = new Pterodactyls(
                this.getSpecies().BABY_START_HEALTH,
                this.getSpecies().BABY_MAX_HEALTH,
                Utility.getRandomGender());
        return newPterodactyls;
    }

    /**
     * @param embryo The embryo to turn into a dinosaur egg.
     * @return A new {@code PterodactylsEgg}.
     */
    @Override
    public DinosaurEgg embryoToEgg(Embryo embryo) {
        return new PterodactylsEgg(this);
    }

    /**
     * @return The species of {@code Pterodactyls}.
     */
    @Override
    public DinosaurSpecies getSpecies() {
        return SPECIES;
    }

    /**
     * Check if the given actor is able to mate with this dinosaur.
     * @param anotherActor Another actor to check against.
     * @param map The map where the other actor currently belongs to.
     * @return True if this dinosaur is able to mate with the other actor, false otherwise.
     */
    @Override
    public boolean canMate(Actor anotherActor, GameMap map) {
        if (anotherActor == null || map == null)
            return false;
        boolean myselfOnTree = map.locationOf(this).getGround() instanceof Tree;
        boolean partnerOnTree = map.locationOf(anotherActor).getGround() instanceof Tree;
        return super.canMate(anotherActor, map) && myselfOnTree && partnerOnTree;
    }

    /**
     * Helper method to update this Pterodactyls' land or flying status.
     * @param location The location this Pterodactyls currently at.
     */
    private void updateCapabilities(Location location) {
        if (location.getGround() instanceof Tree) {
            this.addCapability(ItemCapabilities.TALL);
            this.removeCapability(ItemCapabilities.ON_GROUND);
        }
        else {
            this.addCapability(ItemCapabilities.ON_GROUND);
            this.removeCapability(ItemCapabilities.TALL);
        }

    }
}
