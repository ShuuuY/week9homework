package game.DinosaurSystem;

import edu.monash.fit2099.engine.*;
import game.*;
import game.Action.AttackAction;
import game.DinosaurSystem.DinosaurEggs.AllosaurEgg;
import game.DinosaurSystem.DinosaurEggs.DinosaurEgg;
import game.Item.Corpse;
import game.Item.ItemCapabilities;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Represents an Allosaur in the game who is also of type Carnivore Dinosaur.
 */
public class Allosaur extends Dinosaur {

    /**
     * Number of Allosaur instances already been instantiated in the game.
     */
    private static int numOfInstances = 0;

    /**
     * The species of Allosaur.
     *
     * @see game.DinosaurSystem.DinosaurSpecies
     */
    public static final DinosaurSpecies SPECIES = DinosaurSpecies.ALLOSAUR;

    /**
     * Actor : Integer === Allosaur attacked this {Actor} {Integer} turns ago.
     */
    protected HashMap<Actor, Integer> allPreviouslyAttackedTarget = new HashMap<>();

    /**
     * Constructor.
     * @param startHitPoints Starting hit points of a new instantiated Allosaur.
     * @param maxHitPoints The maximum hit points the new instantiated Allosaur can go up to.
     * @param gender Gender of new instantiated Allosaur.
     */
    public Allosaur(int startHitPoints, int maxHitPoints, Gender gender) {
        super("Allosaur " + gender + " " + (numOfInstances + 1),
                'a', startHitPoints, maxHitPoints, gender);
        this.initializeAttackTargets();
        this.addCapability(ItemCapabilities.ON_GROUND); // all Allosaur can only eat corpses/eggs on ground.
        numOfInstances++;
    }

    /**
     * @param food The food ate by the dinosaur.
     * @return Energy gained by the Allosaur depending on the food type it consumed.
     */
    @Override
    public int energyGainFromFood(Edible food) {
        if (this.ageGroup == AgeGroup.CHILD)
            return 10;
        else if (food instanceof Corpse && ((Corpse)food).typeOfCorpse() == Brachiosaur.class)
            return this.getMaxHitPoints();
        else if (food instanceof Corpse && ((Corpse)food).typeOfCorpse() == Pterodactyls.class)
            return 30;
        else if (food instanceof Corpse)
            return 50;
        else if (food instanceof Pterodactyls)
            return this.getMaxHitPoints();
        else if (food instanceof DinosaurEgg)
            return 10;
        return super.energyGainFromFood(food);
    }

    /**
     * Invoke by the game engine when it's turn for the dinosaur to act.
     * @param actions Actions that the {@code Allosaur} can potentially take.
     * @param lastAction The last action that the {@code Allosaur} took.
     * @param map The GameMap in which the {@code Allosaur} belongs to.
     * @param display The display which contains the {@code Allosaur}.
     * @return The selected action by the {@code Allosaur} based on a series of criteria.
     */
    @Override
    public Action playTurn(Actions actions, Action lastAction, GameMap map, Display display) {
        Action defaultAction = super.playTurn(actions, lastAction, map, display);

        Actor attackTarget = getAttackTarget(map);
        if ((hitPoints < getSpecies().ADULT_MAX_HEALTH) && attackTarget != null) {

            Action nextAction = null;
            if (attackTarget instanceof Stegosaur) {
                nextAction = new AttackAction(attackTarget,
                        getWeapon(20, "bites"), true, 100);
            }
            else if (attackTarget instanceof Pterodactyls) {
                nextAction = new AttackAction(attackTarget,
                        getWeapon(((Pterodactyls) attackTarget).getMaxHitPoints(), "eats"),
                        true, 100);
            }

            if (nextAction != null && defaultAction instanceof MoveActorAction) {
                allPreviouslyAttackedTarget.put(attackTarget, 0);
                return nextAction;
            }
        }

        return defaultAction;
    }

    /**
     * Search through the map this {@code Allosaur} is on to look for a potential attack target.
     * @param map The GameMap this {@code Allosaur} currently on.
     * @return Null if no attack target available on the GameMap, otherwise returns an {@code Actor} attack target.
     */
    private Actor getAttackTarget(GameMap map) {
        Actor targetActor = null;

        Location targetLocation = Utility.searchAdjacentLocations(this, map,
                (location) -> {
                    Actor actor = location.getActor();
                    if (actor instanceof Dinosaur) {
                        boolean isMyTarget = this.hasCapability(((Dinosaur) actor).getSpecies());
                        boolean notAttackedByMeBefore = !(allPreviouslyAttackedTarget.containsKey(actor));
                        return isMyTarget && notAttackedByMeBefore && actor.hasCapability(ItemCapabilities.ON_GROUND);
                    }
                    return false;
                });

        if (targetLocation != null)
            targetActor = targetLocation.getActor();

        return targetActor;
    }

    /**
     * Helper method to create a weapon.
     * @param damage The damage the returned weapon will deal to other actor.
     * @param description A string literal to describe how the attack action performed by the returned weapon.
     * @return A weapon object that has the specified damage.
     */
    private Weapon getWeapon(int damage, String description) {
        return new Weapon() {
            @Override
            public int damage() {
                return damage;
            }

            @Override
            public String verb() {
                return description;
            }
        };
    }

    /**
     * @param food The food fed to the dinosaur.
     * @return Extra energy gained by the {@code Allosaur} if it's fed.
     */
    @Override
    public int extraEnergyGainBeingFed(Edible food) {
        return 0;
    }

    /**
     * @param egg The egg to turn into a child dinosaur.
     * @return A child {@code Allosaur}.
     */
    @Override
    public Dinosaur hatchEggs(DinosaurEgg egg) {
        Dinosaur newAllosaur = new Allosaur(
                this.getSpecies().BABY_START_HEALTH,
                this.getSpecies().BABY_MAX_HEALTH,
                Utility.getRandomGender());
        return newAllosaur;
    }

    /**
     * @param embryo The embryo to turn into a dinosaur egg.
     * @return A new {@code AllosaurEgg}.
     */
    @Override
    public DinosaurEgg embryoToEgg(Embryo embryo) {
        return new AllosaurEgg(this);
    }

    /**
     * @return The species of {@code Allosaur}.
     */
    @Override
    public DinosaurSpecies getSpecies() {
        return SPECIES;
    }

    /**
     * An Allosaur cannot attack the same Stegosaur for the next 20 turns.
     */
    @Override
    protected void tick() {
        super.tick();

        List<Actor> actorToRemove = new ArrayList<>();
        for (Actor actor : allPreviouslyAttackedTarget.keySet()) {
            int numOfTurns = allPreviouslyAttackedTarget.get(actor);
            allPreviouslyAttackedTarget.put(actor, numOfTurns + 1);

            if (numOfTurns > 20)
                actorToRemove.add(actor);
        }

        // To counter "ConcurrentModificationException" in HashMap iterator, cannot remove in above for-each-loop
        for (Actor actor : actorToRemove)
            allPreviouslyAttackedTarget.remove(actor);
    }

    private void initializeAttackTargets() {
        this.addCapability(DinosaurSpecies.STEGOSAUR); // all Allosaurs can attack Stegosaur & Pterodactyls
        this.addCapability(DinosaurSpecies.PTERODACTYLS);
    }
}
