package game.DinosaurSystem;

import edu.monash.fit2099.engine.*;
import game.*;
import game.Action.AttackAction;
import game.DinosaurSystem.DinosaurEggs.DinosaurEgg;
import game.DinosaurSystem.DinosaurEggs.StegosaurEgg;
import game.Item.ItemCapabilities;

/**
 * Represents an Stegosaur in the game who is also of type Herbivore Dinosaur.
 */
public class Stegosaur extends Dinosaur {

	/**
	 * Number of Stegosaur instances already been instantiated in the game.
	 */
	private static int numOfInstances = 0;

	/**
	 * The species of Stegosaur.
	 *
	 * @see game.DinosaurSystem.DinosaurSpecies
	 */
	public static final DinosaurSpecies SPECIES = DinosaurSpecies.STEGOSAUR;

	/**
	 * Constructor.
	 * @param startHitPoints Starting hit points of a new instantiated Stegosaur.
	 * @param maxHitPoints The maximum hit points the new instantiated Stegosaur can go up to.
	 * @param gender Gender of new instantiated Stegosaur.
	 */
	public Stegosaur(int startHitPoints, int maxHitPoints, Gender gender) {
		super("Stegosaur " + gender + " " + (numOfInstances + 1),
				'd', startHitPoints, maxHitPoints, gender);
		this.addCapability(ItemCapabilities.SHORT); // all Stegosaur can only eat fruits on bush/ground.
		this.addCapability(ItemCapabilities.ON_GROUND);
		numOfInstances++;
	}

	/**
	 * @param otherActor the Actor that might be performing attack
	 * @param direction  String representing the direction of the other Actor
	 * @param map        current GameMap
	 * @return Multiple actions which other actor can do to this {@code Stegosaur}.
	 */
	@Override
	public Actions getAllowableActions(Actor otherActor, String direction, GameMap map) {
		Actions allowableActions = super.getAllowableActions(otherActor, direction, map);
		allowableActions.add(new AttackAction(this, getIntrinsicWeapon()));
		return allowableActions;
	}

	/**
	 * @param food The food fed to the dinosaur.
	 * @return Extra energy gained by the {@code Stegosaur} if it's fed.
	 */
	@Override
	public int extraEnergyGainBeingFed(Edible food) {
		return 10;
	}

	/**
	 * @param egg The egg to turn into a child dinosaur.
	 * @return A child {@code Stegosaur}.
	 */
	@Override
	public Dinosaur hatchEggs(DinosaurEgg egg) {
		Dinosaur newStegosaur = new Stegosaur(
				this.getSpecies().BABY_START_HEALTH,
				this.getSpecies().BABY_MAX_HEALTH,
				Utility.getRandomGender());
		return newStegosaur;
	}

	/**
	 * @param embryo The embryo to turn into a dinosaur egg.
	 * @return A new {@code StegosaurEgg}.
	 */
	@Override
	public DinosaurEgg embryoToEgg(Embryo embryo) {
		return new StegosaurEgg(this);
	}

	/**
	 * @return The species of {@code Stegosaur}.
	 */
	@Override
	public DinosaurSpecies getSpecies() {
		return SPECIES;
	}
}
