package game.DinosaurSystem;

import edu.monash.fit2099.engine.*;
import game.*;
import game.Action.LifeCycleChangeAction;
import game.Behaviour.WanderBehaviour;
import game.DinosaurSystem.DinosaurEggs.DinosaurEgg;

/**
 * A class represents dinosaur.
 */
public abstract class Dinosaur extends Actor {

    /**
     * Gender of the dinosaur. Male or Female.
     */
    public final Gender GENDER;

    /**
     * Age group of the dinosaur. Child or Adult.
     */
    public AgeGroup ageGroup = AgeGroup.CHILD;

    /**
     * Age of the dinosaur.
     */
    protected int age = 1;

    /**
     * Thirst level of the dinosaur. Measure of how hydrated it is.
     */
    protected int waterLevel = 60;

    /**
     * A manager that manages all kinds of behaviours of this dinosaur related to breeding.
     */
    protected BreedManager breedManager = new BreedManager(this);

    /**
     * A manager that manages all kinds of behaviours of this dinosaur related to hunger.
     */
    protected HungerManager hungerManager = new HungerManager(this);

    /**
     * Construct.
     *
     * @param name name of Dinosaur
     * @param displayChar displayChar of Dinosaur which will display on the console.
     * @param startHitPoints Starting hit points of a new instantiated Dinosaur.
     * @param maxHitPoints The maximum hit points the new instantiated Dinosaur can go up to.
     * @param gender Gender of new instantiated Dinosaur.
     */
    public Dinosaur(String name, char displayChar, int startHitPoints, int maxHitPoints, Gender gender) {
        super(name, displayChar, startHitPoints);
        this.maxHitPoints = maxHitPoints;
        this.GENDER = gender;
    }

    /**
     * A nested enum class to store Dinosaur's Gender.
     */
    public enum Gender {
        MALE, FEMALE
    }

    /**
     * A nested enum class to store Dinosaur's AgeGroup.
     */
    public enum AgeGroup {
        ADULT, CHILD
    }

    /**
     * Invoked to execute a {@code Dinosaur}
     *
     *
     * @param actions    collection of possible Actions for this Dinosaur
     * @param lastAction The Action this Dinosaur took last turn. Can do interesting things in conjunction with Action.getNextAction()
     * @param map        the map containing the Dinosaur
     * @param display    the I/O object to which messages may be written
     * @return an action that dinosaur will do in current turn.
     */
    @Override
    public Action playTurn(Actions actions, Action lastAction, GameMap map, Display display) {
        tick();

        actions.add((new WanderBehaviour()).getAction(this, map));

        Action action = null;

        // Action priority : (1) lastAction.getNextAction(); (2) LifeCycleChangeAction; (3) mate; (4) hungry;
        Actions priorityActions = new Actions();

        if (lastAction != null && lastAction.getNextAction() != null)
            priorityActions.add(lastAction.getNextAction());

        priorityActions.add(breedManager.getNextAction(map));
        priorityActions.add(hungerManager.getNextAction(map));

        for (Action actionTemp : priorityActions) {
            if (actionTemp instanceof LifeCycleChangeAction) {
                action = actionTemp;
                break;
            }
        }

        // No lifecycle change action, so get the most prioritised action (the first one)
        if (action == null && priorityActions.size() > 0)
            action = priorityActions.get(0);

        if (action == null) // if all the above results in null, return a random action.
            action = actions.get(Utility.getRandomInt(0, actions.size()));

        return action;
    }

    /**
     * Dinosaur should experience passage of time because it is a "living thing" and
     * it can grow, turn old, become hungry, thirsty etc.
     */
    protected void tick() {
        // decrease health & water level by 1 every new turn
        int newTurnHealthDecrease = 1;
        this.hurt(newTurnHealthDecrease);
        waterLevel -= newTurnHealthDecrease;

        age++;
        if (age > getSpecies().BABY_TO_ADULT_TURNS) {
            ageGroup = AgeGroup.ADULT;
            maxHitPoints = getSpecies().ADULT_MAX_HEALTH;
        }

        breedManager.tick();
    }

    /**
     * @return true if and only if hitPoints & water level of the dinosaur is positive.
     */
    @Override
    public boolean isConscious() {
        return super.isConscious() && this.waterLevel > 0;
    }

    /**
     * Check if the given actor is able to mate with this dinosaur.
     * @param anotherActor Another actor to check against.
     * @param map The map where the other actor currently belongs to.
     * @return True if this dinosaur is able to mate with the other actor, false otherwise.
     */
    public boolean canMate(Actor anotherActor, GameMap map) {
        if (anotherActor instanceof Dinosaur) {
            return breedManager.canMateWith((Dinosaur)anotherActor);
        }
        return false;
    }

    /**
     * Check to see if the given food is edible by this dinosaur.
     * @param food The food to check against.
     * @return True if this dinosaur can eat the given food, false otherwise.
     */
    public boolean isEdible(Edible food) {
        return hungerManager.isEdible(food);
    }

    /**
     * @param food The food ate by the dinosaur.
     * @return The energy gained by the dinosaur when it consumes that {@code food}.
     */
    public int energyGainFromFood(Edible food) {
        return hungerManager.energyGainFromFood(food);
    }

    /**
     * @param food The food fed to the dinosaur.
     * @return The extra energy gained by the dinosaur when it get fed with that {@code food}.
     */
    public abstract int extraEnergyGainBeingFed(Edible food);

    /**
     * This method usually get invoked by a {@code DinosaurEgg} object
     * to instantiate a {@code Dinosaur} object.
     *
     * @param egg The egg to turn into a child dinosaur.
     * @return A child dinosaur hatched from the egg. Child dinosaur
     *         is different from adult dinosaur in some dinosaur attributes.
     * @see game.DinosaurSystem.DinosaurEggs.DinosaurEgg#hatch(Location)
     */
    public abstract Dinosaur hatchEggs(DinosaurEgg egg);

    /**
     * This method usually get invoked to instantiate a {@code LayEggAction} object.
     *
     * @param embryo The embryo to turn into a dinosaur egg.
     * @return A dinosaur egg that has the same dinosaur species type as its dinosaur parent.
     * @see game.Action.LayEggAction
     */
    public abstract DinosaurEgg embryoToEgg(Embryo embryo);

    /**
     * Creates an embryo in the dinosaur.
     */
    public void createEmbryo() {
        breedManager.createEmbryo();
    }

    /**
     * @return The species of the dinosaur. One of : Stegosaur, Brachiosaur, Allosaur.
     */
    public abstract DinosaurSpecies getSpecies();

    /**
     * @return The maximum hit points the dinosaur has. It will be different for adult and child dinosaur.
     */
    public int getMaxHitPoints() {
        return this.maxHitPoints;
    }

    /**
     * @return The current hit points the dinosaur has.
     */
    public int getHitPoints() {
        return this.hitPoints;
    }

    /**
     * @return Current water level of this dinosaur.
     */
    public int getWaterLevel() {
        return this.waterLevel;
    }

    /**
     * Increase this dinosaur's water level.
     * @param increment The amount of water level to increase. Must be greater than zero.
     */
    public void increaseWaterLevel(int increment) {
        if (increment > 0) {
            waterLevel += increment;
            waterLevel = Math.min(waterLevel, this.getSpecies().MAX_WATER_LEVEL);
        }
    }

    /**
     * Notify the female parent dinosaur upon completion of lay egg action
     * so that her breed manager can remove the embryo.
     */
    public void notifyDoneLayEgg() {
        breedManager.notifyDoneLayEgg();
    }
}
