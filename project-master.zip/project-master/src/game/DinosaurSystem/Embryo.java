package game.DinosaurSystem;

/**
 * A class represents a state Embryo for only female dinosaur.
 */
class Embryo {
    private int turnsRemaining;

    /**
     * Constructor.
     *
     * @param turnsRemaining initialise the turn that female need to be pregnant.
     */
    Embryo(int turnsRemaining) {
        this.turnsRemaining = turnsRemaining;
    }

    /**
     * Getter
     *
     * @return Remaining turn of pregnancy.
     */
    public int getTurnsRemaining() {
        return turnsRemaining;
    }

    /**
     * Reduce the remaining turn by one turn.
     */
    public void tick() {
        turnsRemaining--;
    }
}
