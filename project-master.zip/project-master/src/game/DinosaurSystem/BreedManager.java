package game.DinosaurSystem;

import edu.monash.fit2099.engine.Action;
import edu.monash.fit2099.engine.GameMap;
import edu.monash.fit2099.engine.Location;
import game.Action.ChainedMoveActorAction;
import game.Action.LayEggAction;
import game.Behaviour.Mating;
import game.Tree;
import game.Utility;

/**
 * Object of this class manages the breeding system of a {@code Dinosaur},
 * including what actions shall it take, what kind of behaviour will it have when the {@code Dinosaur}
 * wants to mate or lay egg.
 */
public class BreedManager {

    /**
     * The dinosaur which this {@code BreedManager} object will help to manage.
     */
    private Dinosaur dinosaur;

    /**
     * A female dinosaur will carry an {@code Embryo} object after execution of {@code MateAction}.
     */
    private Embryo embryo;

    /**
     * Constructor.
     *
     * @param dinosaur The dinosaur whose breeding system is managed by this BreedManager object.
     */
    public BreedManager(Dinosaur dinosaur) {
        this.dinosaur = dinosaur;
    }

    /**
     * @return True if the dinosaur itself wants to mate. False otherwise.
     */
    public boolean isDinosaurLookingToMate() {
        return dinosaur.isConscious()
                && (dinosaur.getHitPoints() >= dinosaur.getSpecies().WELL_FED_LEVEL)
                && (dinosaur.ageGroup != Dinosaur.AgeGroup.CHILD)
                && ((embryo == null) || (embryo.getTurnsRemaining() == dinosaur.getSpecies().EMBRYO_TO_EGG_TURNS));
    }

    /**
     * Does this dinosaur satisfy the conditions in order to mate with the given dinosaur?
     *
     * @param otherDinosaur Check if this input dinosaur is an eligible mate candidate.
     * @return True if {@code otherDinosaur} can mate with this dinosaur. False otherwise.
     */
    public boolean canMateWith(Dinosaur otherDinosaur) {
        return isDinosaurLookingToMate()
                && (dinosaur.getSpecies() == otherDinosaur.getSpecies())
                && (dinosaur.GENDER != otherDinosaur.GENDER)
                && otherDinosaur.breedManager.isDinosaurLookingToMate();
    }

    /**
     * Creates an embryo in this {@code Dinosaur}.
     */
    public void createEmbryo() {
        if (embryo == null)
            embryo = new Embryo(dinosaur.getSpecies().EMBRYO_TO_EGG_TURNS);
    }

    private boolean wantToLayEgg() {
        return embryo != null && embryo.getTurnsRemaining() <= 0;
    }

    /**
     * @param map The {@code GameMap} this dinosaur currently belongs to.
     * @return A breeding-related {@code Action} based on this dinosaur's current breed-related status.
     */
    public Action getNextAction(GameMap map) {
        Action action;
        if (embryo != null && wantToLayEgg()) {
            action = new LayEggAction(dinosaur.embryoToEgg(embryo));

            if (dinosaur instanceof Pterodactyls && !(map.locationOf(dinosaur).getGround() instanceof Tree)) {
                Location layEggLocation = Utility.searchAdjacentLocations(
                        dinosaur, map, (location) -> location.getGround() instanceof Tree);

                action = (layEggLocation == null) ? null : new ChainedMoveActorAction(
                        layEggLocation, "towards tree to lay egg", action);
            }
        }
        else
            action = new Mating().getAction(dinosaur, map);
        return action;
    }

    /**
     * Breed manager needs to know the time passed in order to deliver accurate behaviours or actions.
     */
    public void tick() {
        if (embryo != null) {
            embryo.tick();
        }
    }

    /**
     * Clients (mostly a Dinosaur object) will notify the breed manager upon completion of lay egg action
     * to remove the embryo inside the female dinosaur.
     */
    public void notifyDoneLayEgg() {
        embryo = null;
    }
}
