package game.DinosaurSystem;

import edu.monash.fit2099.engine.Action;
import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.GameMap;
import edu.monash.fit2099.engine.Item;
import game.Action.LifeCycleChangeAction;
import game.Behaviour.Behaviour;
import game.Behaviour.Hungry;
import game.Behaviour.Thirsty;
import game.Edible;
import game.Item.ItemCapabilities;
import game.Utility;

/**
 * Object of this class manages the hunger system of a dinosaur,
 * including what actions shall it take, what kind of behaviour will it have when the dinosaur
 * feels hungry.
 */
public class HungerManager {

    /**
     * The dinosaur which this {@code HungerManager} object will help to manage.
     */
    private Dinosaur dinosaur;

    /**
     * Constructor.
     *
     * @param dinosaur The dinosaur whose hunger system is managed by this {@code HungerManager} object.
     */
    public HungerManager(Dinosaur dinosaur) {
        this.dinosaur = dinosaur;
    }

    private boolean isHungry() {
        return dinosaur.getHitPoints() < dinosaur.getSpecies().HUNGRY_LEVEL;
    }

    private boolean isThirsty() {
        return dinosaur.getWaterLevel() < dinosaur.getSpecies().THIRST_LEVEL;
    }

    /**
     * @param food Food object consumed by the dinosaur.
     * @return The amount of energy gained by the dinosaur if the {@code food} is consumed.
     */
    public int energyGainFromFood(Edible food) {
        return dinosaur.getSpecies().DEFAULT_EAT_HEALTH_INCREASE;
    }

    /**
     * @param map The {@code GameMap} this dinosaur currently belongs to.
     * @return A hunger-related {@code Action} based on this dinosaur's current hunger-related status.
     */
    public Action getNextAction(GameMap map) {

        // If dinosaur is unconscious, get and return next action from unconscious behaviour
        if (!dinosaur.isConscious())
            return new Unconscious().getAction(dinosaur, map);

        // Else return EatAction or DrinkAction based on dinosaur's hunger, thirst status
        Action[] actions = new Action[2];
        if (isHungry())
            actions[0] = new Hungry().getAction(dinosaur, map);

        if (isThirsty())
            actions[1] = new Thirsty().getAction(dinosaur, map);

        int random = Utility.getRandomInt(0, 2);

        Action action = actions[random];

        if (action == null)
            return actions[1 - random];   // doesn't matter if the other action is also null, caller responsible to deal
        else
            return action;
    }

    /**
     * Check whether this dinosaur can eat the given item or not.
     * @param food Edible object to check against.
     * @return True if this dinosaur will be able to consume this food. False otherwise.
     */
    public boolean isEdible(Edible food) {
        Item item = (Item)food;
        boolean result = false;
        boolean dinosaurTall = dinosaur.hasCapability(ItemCapabilities.TALL);
        boolean dinosaurShort = dinosaur.hasCapability(ItemCapabilities.SHORT);
        boolean dinosaurOnGround = dinosaur.hasCapability(ItemCapabilities.ON_GROUND);
        boolean dinosaurWater = dinosaur.hasCapability(ItemCapabilities.WATER);
        for (Class<? extends Edible> edibleClass : dinosaur.getSpecies().getUnmodifiableEdibleFoodTypes()) {
            if (edibleClass.isInstance(item)) {
                if (dinosaurTall && item.hasCapability(ItemCapabilities.TALL))
                    result = true;
                else if (dinosaurShort && item.hasCapability(ItemCapabilities.SHORT))
                    result = true;
                else if (dinosaurOnGround && item.hasCapability(ItemCapabilities.ON_GROUND))
                    result = true;
                else if (dinosaurWater && item.hasCapability(ItemCapabilities.WATER))
                    result = true;

                if (result)
                    break;
            }
        }
        return result;
    }

    /**
     * Represents an unconscious behaviour of an {@code Actor}.
     */
    private class Unconscious implements Behaviour {

        /**
         * What will the {@code actor} do if it has this {@code Unconscious} behaviour.
         *
         * Will the {@code actor} continue to be unconscious or die or get revived ?
         *
         * @param actor the Actor acting
         * @param map the GameMap containing the Actor
         * @return The next action the {@code Actor} will do.
         */
        @Override
        public Action getAction(Actor actor, GameMap map) {
            Action action;

            boolean hungerLimitExceeded
                    = (dinosaur.getHitPoints() + dinosaur.getSpecies().MAX_UNCONSCIOUS_TURNS) == 0;
            boolean thirstLimitExceeded
                    = (dinosaur.getWaterLevel() + dinosaur.getSpecies().THIRSTY_MAX_UNCONSCIOUS_TURNS) == 0;

            if (dinosaur.getHitPoints() > 0 && dinosaur.getWaterLevel() > 0)
                action = new LifeCycleChangeAction(LifeCycleChangeAction.LifeCycleChange.REVIVE);
            else if (hungerLimitExceeded || thirstLimitExceeded)
                action = new LifeCycleChangeAction(LifeCycleChangeAction.LifeCycleChange.DEAD);
            else
                action = new LifeCycleChangeAction(LifeCycleChangeAction.LifeCycleChange.UNCONSCIOUS);

            return action;
        }
    }
}
