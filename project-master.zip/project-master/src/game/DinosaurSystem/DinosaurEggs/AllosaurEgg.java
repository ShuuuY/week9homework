package game.DinosaurSystem.DinosaurEggs;

import game.DinosaurSystem.Allosaur;

/**
 * Represents a dinosaur egg from a female {@code Allosaur}.
 *
 * @see game.DinosaurSystem.Allosaur
 */
public class AllosaurEgg extends DinosaurEgg {

    /**
     * Constructor.
     *
     * @param parent The parent Allosaur who laid this {@code AllosaurEgg} object.
     */
    public AllosaurEgg(Allosaur parent) {
        super(parent);
    }
}
