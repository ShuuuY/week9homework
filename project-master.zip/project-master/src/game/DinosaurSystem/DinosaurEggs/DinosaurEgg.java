package game.DinosaurSystem.DinosaurEggs;

import edu.monash.fit2099.engine.*;
import game.*;
import game.DinosaurSystem.Dinosaur;
import game.Item.ItemCapabilities;
import game.Item.PortableItem;

/**
 * Represents a Dinosaur Egg object.
 *
 * A dinosaur egg is tradeable (can be bought) from the vending machine. Therefore implements {@code EcoPointsTradable}.
 * Player gain EcoPoints from a successful hatch of a dinosaur egg. Therefore implements {@code EcoPointsValuable}.
 * A dinosaur egg is edible. Therefore implements {@code Edible}.
 *
 * @see game.EcoPointsTradable
 * @see game.EcoPointsValuable
 * @see game.Edible
 */
public abstract class DinosaurEgg extends PortableItem implements EcoPointsValuable, EcoPointsTradable,
        Edible {

    /**
     * The parent of this DinosaurEgg object.
     */
    private final Dinosaur PARENT;

    /**
     * Game turns needed before hatching the dinosaur egg.
     */
    private int hatchTime;

    /**
     * The eco points to credit to the player if this dinosaur egg successfully hatched.
     */
    private final int HATCH_VALUE;

    /**
     * The eco points needed to buy a unit of this dinosaur egg from the vending machine.
     */
    private final int TRADE_VALUE;

    /**
     * Constructor.
     *
     * @param parent The parent {@code Dinosaur} who laid this {@code DinosaurEgg} object.
     */
    public DinosaurEgg(Dinosaur parent) {
        super(parent + " Egg", 'e');
        this.PARENT = parent;
        hatchTime = parent.getSpecies().EGG_HATCH_TURNS;
        HATCH_VALUE = parent.getSpecies().EGG_HATCH_ECO_POINTS;
        TRADE_VALUE = parent.getSpecies().EGG_BUY_ECO_POINTS;
        this.addCapability(ItemCapabilities.ON_GROUND);
    }

    /**
     * Dinosaur egg is an item and can experience the passage of time.
     * @param currentLocation The location of the actor carrying this Item.
     * @param actor The actor carrying this Item.
     */
    @Override
    public void tick(Location currentLocation, Actor actor) {
        if (this.hasCapability(ItemCapabilities.REMOVABLE_FROM_GAME))
            actor.removeItemFromInventory(this);
        else if (hatchTime == 0)
            hatch(currentLocation);
        else
            hatchTime--;
    }

    /**
     * Dinosaur egg is an item and can experience the passage of time.
     * @param currentLocation The location of the ground on which we lie.
     */
    @Override
    public void tick(Location currentLocation) {
        if (this.hasCapability(ItemCapabilities.REMOVABLE_FROM_GAME))
            currentLocation.removeItem(this);
        else if (hatchTime == 0)
            hatch(currentLocation);
        else
            hatchTime--;
    }

    /**
     * When the time comes, the dinosaur egg needs to be hatched into a child dinosaur.
     * @param currentLocation The location the dinosaur egg currently at.
     * @return A child {@code Dinosaur} object.
     *
     * @see game.DinosaurSystem.Dinosaur
     */
    public Dinosaur hatch(Location currentLocation) {
        Dinosaur babyDinosaur = PARENT.hatchEggs(this);
        removeEdibleFromLocation();
        Application.ecoPointManager.addEcoPoints(this);
        if (currentLocation.canActorEnter(babyDinosaur))
            currentLocation.addActor(babyDinosaur);
        else {
            Location birthLocation = Utility.searchAdjacentLocations(currentLocation,
                    (location) -> location.canActorEnter(babyDinosaur));

            if (birthLocation != null)
                birthLocation.addActor(babyDinosaur);
        }
        return babyDinosaur;
    }

    /**
     * @return How much the player can gain if this {@code DinosaurEgg} object successfully hatched.
     */
    @Override
    public int getEcoPointsValue() {
        return HATCH_VALUE;
    }

    /**
     * @return How much the player can buy a unit of this {@code DinosaurEgg} from the vending machine.
     */
    @Override
    public int getEcoPointsExchangePrice() {
        return TRADE_VALUE;
    }

    /**
     * Invoked when this {@code DinosaurEgg} object eaten by some actors.
     */
    @Override
    public void removeEdibleFromLocation() {
        this.addCapability(ItemCapabilities.REMOVABLE_FROM_GAME);
    }
}
