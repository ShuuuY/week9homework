package game.DinosaurSystem.DinosaurEggs;

import game.DinosaurSystem.Brachiosaur;

/**
 * Represents a dinosaur egg from a female {@code Brachiosaur}.
 *
 * @see game.DinosaurSystem.Brachiosaur
 */
public class BrachiosaurEgg extends DinosaurEgg {

    /**
     * Constructor.
     *
     * @param parent The parent Brachiosaur who laid this {@code BrachiosaurEgg} object.
     */
    public BrachiosaurEgg(Brachiosaur parent) {
        super(parent);
    }
}
