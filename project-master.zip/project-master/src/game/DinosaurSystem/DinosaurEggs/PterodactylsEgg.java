package game.DinosaurSystem.DinosaurEggs;

import game.DinosaurSystem.Pterodactyls;

/**
 * Represents a dinosaur egg from a female {@code Pterodactyls}.
 *
 * @see game.DinosaurSystem.Pterodactyls
 */
public class PterodactylsEgg extends DinosaurEgg {

    /**
     * Constructor.
     *
     * @param parent The parent Pterodactyls who laid this {@code PterodactylsEgg} object.
     */
    public PterodactylsEgg(Pterodactyls parent) {
        super(parent);
    }
}
