package game.DinosaurSystem.DinosaurEggs;

import game.DinosaurSystem.Stegosaur;

/**
 * Represents a dinosaur egg from a female {@code Stegosaur}.
 *
 * @see game.DinosaurSystem.Stegosaur
 */
public class StegosaurEgg extends DinosaurEgg {

    /**
     * Constructor.
     *
     * @param parent The parent Stegosaur who laid this {@code StegosaurEgg} object.
     */
    public StegosaurEgg(Stegosaur parent) {
        super(parent);
    }
}
