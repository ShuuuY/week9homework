package game.DinosaurSystem;

import game.DinosaurSystem.DinosaurEggs.DinosaurEgg;
import game.DinosaurSystem.MealKits.CarnivoreMealKit;
import game.DinosaurSystem.MealKits.VegetarianMealKit;

import game.Item.Corpse;
import game.Edible;
import game.Item.Fish;
import game.Item.Fruit;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * A class to represents the attributes of dinosaur that are fixed.
 */
public enum DinosaurSpecies {
    STEGOSAUR(100, 90,50,
            10, 30, 100,
            10, 30, 10,
            20, 20,
            20, 100, 200,
            Arrays.asList(VegetarianMealKit.class, Fruit.class)),

    BRACHIOSAUR(160, 140,70,
            5, 80, 200,
            10, 50, 30,
            15, 40,
            30, 1000, 500,
            Arrays.asList(VegetarianMealKit.class, Fruit.class)),

    ALLOSAUR(100,60,50,
            20, 30, 100,
            20, 50, 50,
            20, 20,
            40, 1000, 1000,
            Arrays.asList(Corpse.class, CarnivoreMealKit.class, DinosaurEgg.class)),

    PTERODACTYLS(100, 60, 50,
            10, 30, 100,
            10, 30, 10,
            20, 20,
            20, 100, 200,
            Arrays.asList(Corpse.class, CarnivoreMealKit.class, Fish.class));

    /**
     * The maximum health level of an adult dinosaur.
     */
    public final int ADULT_MAX_HEALTH;

    /**
     * The hungry level a dinosaur has. Health level falls below this hungry level
     * will trigger hunger manager to generate actions.
     *
     * @see HungerManager
     */
    public final int HUNGRY_LEVEL;

    /**
     * The thirst level a dinosaur has. Water level falls below this thirst level
     * will trigger hunger manager to generate actions.
     *
     * @see HungerManager
     */
    public final int THIRST_LEVEL = 40;

    /**
     * The level at which the dinosaur is considered as well-fed.
     */
    public final int WELL_FED_LEVEL;

    /**
     * The default health gained by a dinosaur when eaten a food.
     */
    public final int DEFAULT_EAT_HEALTH_INCREASE;

    /**
     * The default water level gained by a dinosaur when drink water.
     */
    public final int DEFAULT_DRINK_WATER_LEVEL_INCREASE;

    /**
     * The maximum water level a dinosaur can have.
     */
    public final int MAX_WATER_LEVEL;

    /**
     * The starting health of a baby dinosaur.
     */
    public final int BABY_START_HEALTH;

    /**
     * The maximum health level a baby dinosaur has.
     */
    public final int BABY_MAX_HEALTH;

    /**
     * How many turns for the baby dinosaur to turn into an adult dinosaur.
     */
    public final int BABY_TO_ADULT_TURNS;

    /**
     * How many turns the embryo in a female dinosaur should develop before laying the egg.
     */
    public final int EMBRYO_TO_EGG_TURNS;

    /**
     * The maximum number of turns the dinosaur is allowed to be unconscious.
     */
    public final int MAX_UNCONSCIOUS_TURNS;

    /**
     * The maximum number of game turns the dinosaur will be in unconscious state due to thirst.
     */
    public final int THIRSTY_MAX_UNCONSCIOUS_TURNS = 15;

    /**
     * The number of turns the corpse of the dinosaur shall stay on ground.
     */
    public final int CORPSE_ON_GROUND_TIME;

    /**
     * The number of turns the dinosaur egg should wait before getting hatched.
     */
    public final int EGG_HATCH_TURNS;

    /**
     * The EcoPoints gained when a dinosaur egg successfully hatches.
     */
    public final int EGG_HATCH_ECO_POINTS;

    /**
     * The EcoPoints needed to buy a unit of this dinosaur egg from the vending machine.
     */
    public final int EGG_BUY_ECO_POINTS;

    /**
     * A list of food Classes edible by the dinosaur.
     */
    private List<Class<? extends Edible>> edibleFoodTypes;

    DinosaurSpecies(int adultMaxHitPoints, int hungryLevel, int wellFedLevel,
                    int defaultEatHealthIncrease, int drinkIncrease, int maxWaterLevel,
                    int babyStartHealth, int babyToAdultNumOfTurns, int embryoToEggTurns,
                    int maxUnconsciousTurns, int corpseOnGroundTime,
                    int eggHatchTurns, int eggHatchPoints, int eggBuyPoints,
                    List<Class<? extends Edible>> edibleFoodTypes) {
        this.ADULT_MAX_HEALTH = adultMaxHitPoints;
        this.HUNGRY_LEVEL = hungryLevel;
        this.WELL_FED_LEVEL = wellFedLevel;
        this.DEFAULT_EAT_HEALTH_INCREASE = defaultEatHealthIncrease;
        this.DEFAULT_DRINK_WATER_LEVEL_INCREASE = drinkIncrease;
        this.MAX_WATER_LEVEL = maxWaterLevel;
        this.BABY_START_HEALTH = babyStartHealth;
        this.BABY_TO_ADULT_TURNS = babyToAdultNumOfTurns;
        this.EMBRYO_TO_EGG_TURNS = embryoToEggTurns;
        this.MAX_UNCONSCIOUS_TURNS = maxUnconsciousTurns;
        this.CORPSE_ON_GROUND_TIME = corpseOnGroundTime;
        this.EGG_HATCH_TURNS = eggHatchTurns;
        this.EGG_HATCH_ECO_POINTS = eggHatchPoints;
        this.EGG_BUY_ECO_POINTS = eggBuyPoints;
        this.BABY_MAX_HEALTH = ADULT_MAX_HEALTH/2;
        this.edibleFoodTypes = edibleFoodTypes;
    }

    /**
     * @return a list of classes whose objects are edible to the dinosaur.
     */
    public List<Class<? extends Edible>> getUnmodifiableEdibleFoodTypes() {
        return Collections.unmodifiableList(edibleFoodTypes);
    }
}
