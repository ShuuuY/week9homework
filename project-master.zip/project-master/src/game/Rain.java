package game;

import edu.monash.fit2099.engine.GameMap;
import edu.monash.fit2099.engine.Location;
import game.Action.DrinkAction;

/**
 * A class is responsible for calculate the rainfall.
 *
 */
public class Rain {
    private double rainfall;

    /**
     * Constructor.
     */
    public Rain() {
        rainfall = Utility.getRandomInt(1, 7) * 0.1;
    }

    /**
     * If there is rainfall, the unconscious dinosaur will be watered
     * and all the lakes will be increased the volume.
     *
     * @param map current game map
     */
    public void execute(GameMap map) {
        System.out.println("It's raining now!\n");
        for (int y : map.getYRange()) {
            for (int x : map.getXRange()) {
                Location location = map.at(x, y);
                if (location.containsAnActor() && !map.getActorAt(location).isConscious()) {
                    String execution = new DrinkAction(10).execute(map.getActorAt(location), map);
                    System.out.println(execution);
                }

                if (location.getGround() instanceof Lake)
                    ((Lake) location.getGround()).increaseCapacity(rainfall);
            }
        }

    }
}
