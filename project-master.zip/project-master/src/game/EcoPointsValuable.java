package game;

/**
 * An interface that all objects will implement if a successful completion of them
 * can credit EcoPoints to the player.
 */
public interface EcoPointsValuable {

    /**
     * @return The amount of EcoPoints that will be credited into the player's eco wallet.
     */
    int getEcoPointsValue();
}
