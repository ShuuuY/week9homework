package game;

import edu.monash.fit2099.engine.Ground;
import edu.monash.fit2099.engine.Item;
import edu.monash.fit2099.engine.Location;
import game.Item.Bush;

/**
 * A class that represents bare dirt.
 */
public class Dirt extends Ground {

	/**
	 * Constructor
	 */
	public Dirt() {
		super('.');
	}

	/**
	 * Grow a bush.
	 *
	 * @see Ground#tick(Location)
	 * @param location The location of the Dirt.
	 */
	@Override
	public void tick(Location location) {
		super.tick(location);

		boolean hasBush = getBush(location);

		Bush bush = null;
		if (!hasBush && !getNearbyIsTree(location))
			bush = growBush(0.0002);
		else if (!hasBush && getNearbyIsBush(location))
			bush = growBush(0.002);

		if (bush != null)
			location.addItem(bush);
	}

	private boolean getBush(Location location) {
		for (Item item : location.getItems()) {
			if (item instanceof Bush)
				return true;
		}
		return false;
	}

	/**
	 * Grow a new bush randomly.
	 *
	 * @return a new bush
	 */
	private Bush growBush(double probability) {
		int stopAt = (int)(1 / probability);
		if (Utility.getRandomInt(0, stopAt) < 1) {
			return new Bush();
		}
		return null;
	}

	/**
	 * Check if there is a tree around the location of bush grows.
	 *
	 * @param location where the bush grows up
	 * @return return true if there is no tree around where the bush grows up
	 */
	private boolean getNearbyIsTree(Location location){

		Location treeLocation = Utility.searchAdjacentLocations(location,
				(destinationLocation) -> destinationLocation.getGround() instanceof Tree);

		return treeLocation != null;
	}

	/**
	 * Check if there is a bush around the location of bush grows.
	 *
	 * @param location where the bush grows up
	 * @return return true if there is a bush around the location where the bush grows up
	 */
	private boolean getNearbyIsBush(Location location) {

		Location nextDirtLocation = Utility.searchAdjacentLocations(location,
				(destinationLocation) -> {
					Ground destinationGroundType = destinationLocation.getGround();
					if (destinationGroundType instanceof Dirt)
						return ((Dirt) destinationGroundType).getBush(destinationLocation);
					return false;
				});

		return nextDirtLocation != null;
	}
}

