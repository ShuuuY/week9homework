package game;

/**
 * An interface that all objects will implement if they can be bought from Vending Machine.
 */
public interface EcoPointsTradable {

    /**
     * @return The amount of eco points needed to buy a unit of {@code EcoPointsTradable} object
     *         from the vending machine.
     */
    int getEcoPointsExchangePrice();
}
