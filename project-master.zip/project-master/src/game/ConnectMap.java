package game;

import edu.monash.fit2099.engine.*;

import java.util.List;

/**
 * A class for the current map with more functions than the GameMap clasee before.
 */
public class ConnectMap extends GameMap {
    private ConnectMap north;
    private ConnectMap south;
    private int turnsSoFar;

    /**
     * Constructor that creates a map from a sequence of ASCII strings.
     *
     * @param groundFactory Factory to create Ground objects
     * @param lines         List of Strings representing rows of the map
     */
    public ConnectMap(GroundFactory groundFactory, List<String> lines) {
        super(groundFactory, lines);
    }

    /**
     * Initialise the north map.
     *
     * @param north north map
     */
    public void setNorth(ConnectMap north) {
        this.north = north;
    }

    /**
     * Initialise the south map.
     *
     * @param south south map
     */
    public void setSouth(ConnectMap south) {
        this.south = south;
    }

    /**
     * Builder method for making Exits.
     *
     * @param here   the current location
     * @param x      X coordinate
     * @param y      Y coordinate
     * @param name   name of the Exit
     * @param hotKey the hotkey for the appropriate Action
     */
    protected void addExitFromHere(Location here, int x, int y, String name, String hotKey) {
        if (widths.contains(x) && heights.contains(y)) {
            here.addExit(new Exit(name, this.at(x, y), hotKey));
        }
        if (here.y() == 0 && north != null && y < 0 && widths.contains(x)) {
            here.addExit(new Exit(name, north.at(x, north.heights.max()), hotKey));
        }
        if (here.y() == heights.max() && south != null && y > heights.max() && widths.contains(x)) {
            here.addExit(new Exit(name, south.at(x, 0), hotKey));
        }
    }

    /**
     * Initialise new maps.
     *
     * @param width  width of the map, in characters
     * @param height height of the map, in characters
     */
    @Override
    protected void initMap(int width, int height) {
        widths = new NumberRange(0, width);
        heights = new NumberRange(0, height);
        map = new Location[width][height]; // Note the ordering. 0, 0 is the top left.
        // First arg is across, second down
        for (int x : widths) {
            for (int y : heights) {
                map[x][y] = makeNewLocation(x, y);
            }
        }

    }

    /**
     * Check if the game world will rainy and call Rain object execute() if it rains.
     */
    @Override
    public void tick() {
        super.tick();
        // Rainfall in every 10 turns
        turnsSoFar++;
        if ((turnsSoFar % 10) == 0 && Utility.getRandomInt(0, 10) <= 9)
            new Rain().execute(this);
    }

    /**
     * The direction that the actor can go currently.
     */
    public void buildMapComplete() {
        for (int x : widths) {
            for (int y : heights) {
                Location here = this.at(x, y);
                addExitFromHere(here, x, y - 1, "North", "8");
                addExitFromHere(here, x + 1, y - 1, "North-East", "9");
                addExitFromHere(here, x + 1, y, "East", "6");
                addExitFromHere(here, x + 1, y + 1, "South-East", "3");
                addExitFromHere(here, x, y + 1, "South", "2");
                addExitFromHere(here, x - 1, y + 1, "South-West", "1");
                addExitFromHere(here, x - 1, y, "West", "4");
                addExitFromHere(here, x - 1, y - 1, "North-West", "7");
            }
        }
    }
}

