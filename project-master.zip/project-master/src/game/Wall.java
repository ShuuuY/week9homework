package game;

import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.Ground;

/**
 * Represents a wall in the game map.
 */
public class Wall extends Ground {

	/**
	 * Empty argument constructor.
	 */
	public Wall() {
		super('#');
	}

	/**
	 * @param actor the Actor to check
	 * @return Always false since no one can "enter" a wall.
	 */
	@Override
	public boolean canActorEnter(Actor actor) {
		return false;
	}

	/**
	 * @return Always true as a wall is impassable.
	 */
	@Override
	public boolean blocksThrownObjects() {
		return true;
	}
}
