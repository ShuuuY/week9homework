package game.Action;

import edu.monash.fit2099.engine.*;
import game.DinosaurSystem.Allosaur;
import game.DinosaurSystem.Dinosaur;
import game.Item.Corpse;
import game.Utility;

/**
 * Special Action for attacking other Actors.
 */
public class AttackAction extends Action {

	/**
	 * The Actor that is to be attacked
	 */
	private Actor target;
	private Weapon attackWeapon;
	private boolean healActor;
	private int damageToHealthPercentage;
	private Action nextAction;

	/**
	 * Constructor.
	 * 
	 * @param target The Actor to attack.
	 * @param weapon The weapon the attacker will be using to attack.
	 */
	public AttackAction(Actor target, Weapon weapon) {
		this.target = target;
		this.attackWeapon = weapon;
	}

	/**
	 * Constructor to include more details about an {@code AttackAction}.
	 * @param target The Actor to attack.
	 * @param weapon The weapon the attacker will be using to attack.
	 * @param healActor True if the {@code AttackAction} will heal the attacker. False otherwise.
	 * @param healPercentage The amount of health to heal the attacker.
	 */
	public AttackAction(Actor target, Weapon weapon, boolean healActor, int healPercentage) {
		this.target = target;
		this.attackWeapon = weapon;
		this.healActor = healActor;
		this.damageToHealthPercentage = healPercentage;
	}

	/**
	 * Invoked to execute an {@code AttackAction}.
	 * @param actor The actor performing the action.
	 * @param map The map the actor is on.
	 * @return A descriptive string of what has happened as a result of the {@code AttackAction}.
	 */
	@Override
	public String execute(Actor actor, GameMap map) {

		if (Utility.getRandomInt(0, 2) == 0) {
			return actor + " misses " + target + ".";
		}

		int damageDealt = attackWeapon.damage();
		String result = actor + " " + attackWeapon.verb() + " " + target + " for " + damageDealt + " damage.";

		Location deadLocation = null;
		Corpse corpse = null;
		target.hurt(damageDealt);
		if (!target.isConscious()) {
			deadLocation = map.locationOf(target);
			LifeCycleChangeAction deadAction =
					new LifeCycleChangeAction(LifeCycleChangeAction.LifeCycleChange.DEAD);
			result += deadAction.execute(target, map);
			if (actor instanceof Allosaur) {
				corpse = deadAction.getDeadCorpse();
				Action action = new EatAction(corpse);
				nextAction = new ChainedMoveActorAction(
						deadLocation,
						"towards " + target + " corpse",
						action);
			}
		}

		if (healActor)
			actor.heal(damageDealt * (damageToHealthPercentage / 100));

		// If dinosaur actor already full, then no need eat action, remove the corpse from ground as well.
		if (((Dinosaur)actor).getHitPoints() == ((Dinosaur)actor).getMaxHitPoints()
				&& deadLocation != null && corpse != null) {
			nextAction = null;
			deadLocation.removeItem(corpse);
		}

		return result;
	}

	/**
	 * Invoked by the game engine should the {@code AttackAction} is a possible option for the player.
	 * @param actor The actor performing the action.
	 * @return A string that will be displayed on console to describe the {@code AttackAction}
	 * 		   to be performed by the player.
	 */
	@Override
	public String menuDescription(Actor actor) {
		return actor + " attacks " + target;
	}

	/**
	 * @return The next action that the actor will take after performing this {@code AttackAction}.
	 */
	@Override
	public Action getNextAction() {
		if (nextAction != null)
			return nextAction;
		return super.getNextAction();
	}
}
