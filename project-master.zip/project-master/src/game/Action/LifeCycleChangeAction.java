package game.Action;

import edu.monash.fit2099.engine.Action;
import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.GameMap;
import game.Item.Corpse;

/**
 * Represents a life cycle change action of an {@code Actor}.
 *
 * Alive -> Unconscious -> Revive/Dead
 */
public class LifeCycleChangeAction extends Action {

    /**
     * Possible lifecycle changes an {@code Actor} will experience.
     */
    public enum LifeCycleChange {
        DEAD(" is dead."),
        REVIVE(" is revived."),
        UNCONSCIOUS(" is unconscious.");

        /**
         * A descriptive string about the lifecycle state itself.
         */
        public final String DISPLAY_MESSAGE;
        private Corpse deadCorpse = null;

        LifeCycleChange(String displayMsg) {
            this.DISPLAY_MESSAGE = displayMsg;
        }

        /**
         * Only possible to set on a dead lifecycle change.
         * @param corpse The corpse of the {@code Actor}.
         */
        public void setDeadCorpse(Corpse corpse) {
            if (this == DEAD && corpse != null)
                this.deadCorpse = corpse;
        }

        /**
         * Retrieve the corpse of the actor in case the caller needs it to perform some extra action.
         *
         * Privacy leaks not intended to avoid as caller wants to do something to the corpse, say, eat the corpse.
         *
         * @return The corpse of the actor.
         */
        public Corpse getDeadCorpse() {
            return deadCorpse;
        }
    }

    private LifeCycleChange lifeCycleChange;

    /**
     * Constructor.
     *
     * @param lifeCycleChange A lifecycle change state.
     * @see game.Action.LifeCycleChangeAction.LifeCycleChange
     */
    public LifeCycleChangeAction(LifeCycleChange lifeCycleChange) {
        this.lifeCycleChange = lifeCycleChange;
    }

    /**
     * Invoked to execute a {@code LifeCycleChangeAction}.
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return A descriptive string of what has happened as a result of the {@code LifeCycleChangeAction}.
     */
    @Override
    public String execute(Actor actor, GameMap map) {

        if (lifeCycleChange == LifeCycleChange.DEAD)
            lifeCycleChange.setDeadCorpse(Corpse.turnActorToCorpse(actor, map));

        return menuDescription(actor);
    }

    /**
     * Invoked by the game engine should the {@code LifeCycleChangeAction} is a possible option for the player.
     * @param actor The actor performing the action.
     * @return A string that will be displayed on console to describe the {@code LifeCycleChangeAction}
     * 		   to be performed by the player.
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor + lifeCycleChange.DISPLAY_MESSAGE;
    }

    /**
     * Retrieve the corpse of the actor in case the caller needs it to perform some extra action.
     *
     * Privacy leaks not intended to avoid as caller wants to do something to the corpse, say, eat the corpse.
     *
     * @return The corpse of the actor.
     */
    public Corpse getDeadCorpse() {
        if (lifeCycleChange == LifeCycleChange.DEAD)
            return lifeCycleChange.getDeadCorpse();
        else
            return null;
    }
}
