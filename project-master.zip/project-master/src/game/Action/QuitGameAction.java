package game.Action;
import edu.monash.fit2099.engine.Action;
import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.GameMap;
import game.Player;

/**
 * A class for player to quit.
 */
public class QuitGameAction extends Action {

    /**
     * A message display after player quit from game.
     *
     * @param actor The player performing the action.
     * @param map The map the player is on.
     * @return A message display after player quit from game
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        ((Player) actor).leaveGame();
        return "Quit current game successfully.";
    }

    /**
     * Represent a command for quitting from game for the player
     *
     * @param actor The actor performing the action.
     * @return a quit command on the console.
     */
    @Override
    public String menuDescription(Actor actor) {
        return "Quit current game.";
    }

    /**
     * Returns the key used in the menu to trigger QuitGameAction.
     *
     * @return The key we use for this QuitGameAction in the menu.
     */
    @Override
    public String hotkey() {
        return "0";
    }
}
