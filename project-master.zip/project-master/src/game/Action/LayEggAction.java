package game.Action;

import edu.monash.fit2099.engine.*;
import game.DinosaurSystem.Dinosaur;
import game.DinosaurSystem.DinosaurEggs.DinosaurEgg;

/**
 * Represents a lay egg action which normally gets instantiated when the embryo in
 * a female dinosaur is fully developed.
 */
public class LayEggAction extends Action {

    private DinosaurEgg dinosaurEgg;

    /**
     * Constructor.
     *
     * @param dinosaurEggs The DinosaurEgg object to be placed on the game map.
     */
    public LayEggAction(DinosaurEgg dinosaurEggs) {
        this.dinosaurEgg = dinosaurEggs;
    }

    /**
     * Invoked to execute a {@code LayEggAction}.
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return A descriptive string of what has happened as a result of the {@code LayEggAction}.
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        Location actorLocation = map.locationOf(actor);
        actorLocation.addItem(dinosaurEgg);
        if (actor instanceof Dinosaur)
            ((Dinosaur)actor).notifyDoneLayEgg();
        return menuDescription(actor);
    }

    /**
     * Invoked by the game engine should the {@code LayEggAction} is a possible option for the player.
     * @param actor The actor performing the action.
     * @return A string that will be displayed on console to describe the {@code LayEggAction}
     * 		   to be performed by the player.
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor + " is now laying eggs";
    }
}
