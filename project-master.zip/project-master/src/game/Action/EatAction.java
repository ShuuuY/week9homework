package game.Action;

import edu.monash.fit2099.engine.Action;
import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.GameMap;
import game.DinosaurSystem.Dinosaur;
import game.DinosaurSystem.Pterodactyls;
import game.Edible;
import game.Item.Corpse;

/**
 * Represents an Eat Action by an {@code Actor}.
 */
public class EatAction extends Action {

    /**
     * The food to consume when this EatAction gets executed.
     */
    protected Edible food;

    /**
     * Constructor.
     *
     * @param food Must implement {@link game.Edible}.
     */
    public EatAction(Edible food){
        this.food = food;
    }

    /**
     * Invoked to execute an {@code EatAction}.
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return A descriptive string of what has happened as a result of the {@code EatAction}.
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        String result = "";
        if (actor instanceof Dinosaur) {
            Dinosaur actorDinosaur = (Dinosaur)actor;
            int energyGained = actorDinosaur.energyGainFromFood(food);
            actorDinosaur.heal(energyGained);
            if (actor instanceof Pterodactyls && food instanceof Corpse)
                ((Corpse)food).decrementCorpseLife(((Pterodactyls)actor).energyGainFromFood(food));
            else
                food.removeEdibleFromLocation();
            result = actor + " has eaten " + food + " and gained " + energyGained;
        }
        return result;
    }

    /**
     * Invoked by the game engine should the {@code EatAction} is a possible option for the player.
     * @param actor The actor performing the action.
     * @return A string that will be displayed on console to describe the {@code EatAction}
     * 		   to be performed by the player.
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor + " to eat " + food;
    }
}
