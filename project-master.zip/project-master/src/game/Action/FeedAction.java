package game.Action;

import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.GameMap;
import game.Application;
import game.DinosaurSystem.Dinosaur;
import game.Edible;
import game.EcoPointsValuable;

/**
 * For a Dinosaur, to be fed by the player.
 */
public class FeedAction extends EatAction implements EcoPointsValuable {

    private int ecoPointsGained = 10;
    private int extraEnergyGained;
    private Actor targetActor;

    /**
     * Constructor.
     *
     * @param targetActor The actor to feed.
     * @param food The food to feed the actor with.
     * @param ecoPointsGained Amount of EcoPoints gained by the player if successfully executed.
     * @param extraEnergyGained Amount of extra energy gained by the actor being fed.
     */
    public FeedAction(Actor targetActor, Edible food, int ecoPointsGained, int extraEnergyGained) {
        super(food);
        this.ecoPointsGained = ecoPointsGained;
        this.extraEnergyGained = extraEnergyGained;
        this.targetActor = targetActor;
    }

    /**
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return A descriptive string of what has happened as a result of the {@code FeedAction}.
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        String result = super.execute(targetActor, map);
        if (targetActor instanceof Dinosaur) {
            Dinosaur actorDinosaur = (Dinosaur)targetActor;
            if (extraEnergyGained <= 0)
                extraEnergyGained = actorDinosaur.extraEnergyGainBeingFed(food);
            actorDinosaur.heal(extraEnergyGained);
            result += " + " + extraEnergyGained + "(extra)";
        }
        Application.ecoPointManager.addEcoPoints(this);
        result += ", player gained " + this.getEcoPointsValue() + " EcoPoints.";
        return result;
    }

    /**
     * Invoked by the game engine should the {@code FeedAction} is a possible option for the player.
     * @param actor The actor performing the action.
     * @return A string that will be displayed on console to describe the {@code FeedAction}
     * 		   to be performed by the player.
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor + " feeds " + targetActor +  " with " + food;
    }

    /**
     * How much does this {@code FeedAction} worth in terms of EcoPoints if successfully performed.
     * @return The amount of EcoPoints gained by the player if this {@code FeedAction} successfully executed.
     */
    @Override
    public int getEcoPointsValue() {
        return ecoPointsGained;
    }
}
