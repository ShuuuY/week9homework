package game.Action;

import edu.monash.fit2099.engine.*;

/**
 * Represents a compound action composed of {@code MoveActorAction} + {@code Action}.
 *
 * First step : perform {@code MoveActorAction}.
 * Second step : perform {@code Action}.
 */
public class ChainedMoveActorAction extends MoveActorAction {

    private Action nextAction;

    /**
     * Constructor.
     *
     * @param moveToLocation The location the actor needs to move to.
     * @param direction The direction the actor needs to heads in.
     * @param nextAction The next action that the actor will take after performing this {@code ChainedMoveActorAction}.
     */
    public ChainedMoveActorAction(Location moveToLocation, String direction, Action nextAction) {
        super(moveToLocation, direction);
        this.nextAction = nextAction;
    }

    /**
     * @return The next action that the actor will take after performing this {@code AttackAction}.
     */
    @Override
    public Action getNextAction() {
        return nextAction;
    }
}
