package game.Action;

import edu.monash.fit2099.engine.Action;
import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.GameMap;
import game.DinosaurSystem.Dinosaur;

public class DrinkAction extends Action {

    private int waterLevelIncrease;

    /**
     * Constructor.
     * @param waterLevelIncrease When DrinkAction executed, the amount of water level to add to the Actor's water level.
     */
    public DrinkAction(int waterLevelIncrease) {
        setWaterLevelIncrease(waterLevelIncrease);
    }

    /**
     *
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return A description of what happened that can be displayed to the user.
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        String result = "";

        if (actor instanceof Dinosaur) {
            ((Dinosaur)actor).increaseWaterLevel(waterLevelIncrease);
            result += actor + " drinks water and gained " + waterLevelIncrease + " water points";
        } else
            result += actor + " drinks water";
        return result;
    }

    /**
     *
     * @param actor The actor performing the action.
     * @return the text to put on the menu
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor + " to drink water";
    }

    private void setWaterLevelIncrease(int increment) {
        if (increment > 0)
            this.waterLevelIncrease = increment;
    }
}
