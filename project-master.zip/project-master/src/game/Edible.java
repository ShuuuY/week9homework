package game;

/**
 * An interface that all objects will implement if they can be eaten by Dinosaur.
 */
public interface Edible {

    /**
     * To delete a food from the game after a food been eaten by the dinosaur.
     */
    void removeEdibleFromLocation();
}
